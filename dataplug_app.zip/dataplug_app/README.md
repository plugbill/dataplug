# DataPlug (Android)

Native Kotlin + Jetpack Compose app. Backend: the PlugBill PHP API (see data/ApiConfig.kt for the base URL).

- applicationId `com.dataplug.vtu.app`, targetSdk 36 (Google Play requirement), minSdk 24 (Android 7.0).
- Signing and cloud build: read SIGNING.md and KEYSTORE-DETAILS.txt.
- Play Store checklist and what was fixed: PLAY-STORE.md.

## Package change
applicationId changed from com.plugbill.linexware.app to com.dataplug.vtu.app (new Play listing). Replace app/google-services.json with the file downloaded from Firebase after registering the new package; the current second client entry is a placeholder so the build passes, but push notifications need the real one. Kotlin namespace (com.example.walletapp) is unchanged on purpose.
