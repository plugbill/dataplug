# DataPlug rebrand notes

UI-only rebuild of PlugBill in the DataPlug design. `data/`, `services/`, signing files, `applicationId`, `google-services.json`, `gradle.properties`, wrapper and workflow are byte-identical to the input. **Not compiled in the authoring sandbox (no Gradle / Android SDK there): run `./gradlew assembleDebug` first and fix anything the compiler reports.**

## Design spec (from the DataPlug prototype)
- Colours: primary #7C3AED, light #8B5CF6, dark #6D28D9, tint #EDE9FE, bg #F4F2F8 / dark #0D0918, ink #16121F / #F4F1FF, muted #8A8697 / #A59FB8, line #E4DFF0 / #34285A, red #E5484D. Gradient 135deg #9F67FF > #7C3AED > #5B21B6. Credits purple, debits red.
- Shape: cards 26, tiles 28, big service cards 30, sheets 34 top, panels 40 top, buttons and chips fully round (58 / 42 high), fields 18 radius with 1.5 line border, nav pill 78 high.
- Motion: spring (damping ~0.6) on press scale (.93), nav pill, switch knob, dots; staggered 55 ms entrances; 4 s tile/icon float; drifting purple glows; hero orbs and pulsing rings.
- Icons: 12 glossy 3D icons redrawn as vectors in `GlossIcons.kt` (Air, Data, Elec, Tv, Scan, Help, Bet, Fly, Fund, Bills, Moon, More).
- Font: prototype uses Plus Jakarta Sans. Not bundled (no network when building this); Outfit kept.

## Screen mapping
| PlugBill | DataPlug | Backend calls kept |
|---|---|---|
| SplashScreen | splash (hero, logo, dots) | maintenance, session check, Sync.refresh (AppRoot unchanged) |
| OnboardingScreen | onboard | none |
| WelcomeScreen | hero + panel | none |
| Login/Register/Otp/Forgot/Reset/Success | login/register/verify/created (re-themed shell) | AuthFlow.* unchanged |
| PasscodeScreen / SecurityGate | passcode / fingerprint (re-themed) | SecureStore, SecurityGuard, Biometrics unchanged |
| HomeScreen | home | Sync.refresh, UserAPI.updateProfile(hide_balance) |
| (new tab) BillsScreen | bills | opens existing ServiceScreen |
| HistoryScreen (now a tab) | transactions | Sync.loadMoreHistory, same TxStore |
| ServiceScreen, PayPin, Fund, Receipt, Profile, Referral, Notifications, Expenses, Support, Security | inner screens (shared components restyled) | unchanged |

## Files
- Added: `ui/GlossIcons.kt`, `ui/Hero.kt`, `ui/Motion.kt`, `ui/BillsScreen.kt`, `res/drawable/ic_launcher_bg.xml`, `res/drawable-nodpi/dataplug_logo.png`.
- Rewritten: `MainShell`, `HomeScreen`, `HistoryScreen`, `OnboardingScreen`, `TxSkeleton`, splash and welcome in `AuthScreens`, `Theme`, shared parts of `Kit`, `TxViews`, `ic_notification.xml`, colours, strings, launcher icons, `success_anim.json` colour.
- Changed: `AppRoot` (4 tabs, Screen.History removed), `AppIcons`, `Services` (glossy header icon), `Session` (initial), user-visible text in `ui/*`, `ReceiptActivity`, manifest (label, Zara removed).
- Deleted: `ZaraScreen.kt`, `ZaraVoice.kt`, `data/Zara.kt`, `ZaraActivity.kt`, `zara_avatar.png`, `plugbill_logo.png`, RECORD_AUDIO + microphone feature, quick-pay menu and centre button, BubbleShape/BarShape/SvgPathShape/ActionIcon/AvatarIllustration.

## Approximations and things left alone
- Tab 4 is Profile (as specified), not the prototype's "Menu".
- "Scan" tile and "Betting" / "Flight Booking" cards show a "coming soon" toast: no backend exists (PlugBill had Flights/Education as soon-tiles too).
- Account-number card (9PSB copy / generate) kept under the Fund Wallet button; DataPlug has no equivalent.
- Lock-app button added to the Home top bar (the old Home had the callback but no button).
- "Last updated" chip always reads "Updated moments ago"; no timestamp is stored.
- Service flows, PIN pad, Profile sub-screens, Referral, Expenses, Security and dialogs inherit the new colours, pill buttons, chips, fields and switches but keep their previous layouts.
- Dark mode: follows the existing system/user setting; the purple dark palette is applied.
- Kept on purpose (backend or protected): class names `PlugBill*` in `services/`, `R.color.plugbill_green` (now purple, read by services/), SharedPreferences names `plugbill_session` / `plugbill_onboarding`, the passcode hash salt, the `"PlugBill"` provider literal compared with API data, all URLs and `support@plugbill.com`, notification channel ids and any text inside `services/` (push titles are protected).
