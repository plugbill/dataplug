# Signing and cloud build (PERMANENT RULES)

**Key:** `plugbill-permanent.jks`, alias `plugbill`, passwords in `keystore.properties` and `KEYSTORE-DETAILS.txt`.
**SHA-256 of the key:** `DF:8E:9F:F2:A6:59:35:EF:83:B6:66:77:86:E3:82:CA:65:B3:27:8B:41:5E:30:79:BC:85:2C:AA:25:74:00:BF` (also in `EXPECTED_SHA256.txt`).

## How GitHub builds and signs
1. The repository (PRIVATE) contains `dataplug_app.zip` and `.github/workflows/build.yml`.
2. On every push to main/master (or Actions > Run workflow) GitHub unzips `dataplug_app.zip`, finds `settings.gradle.kts`,
   and runs `gradle assembleRelease bundleRelease` with Gradle 8.11.1 and JDK 17.
3. `app/build.gradle.kts` reads `keystore.properties` in the project root, which points at `plugbill-permanent.jks`. The release build is signed with it.
4. The workflow then runs `apksigner verify` and compares the APK's certificate SHA-256 with `EXPECTED_SHA256.txt`. A mismatch fails the build.
5. The APK is APK and AAB are downloadable from the run under Artifacts (DataPlug-APK, DataPlug-AAB-for-PlayStore).

## Rules for any developer or AI editing this project
- NEVER generate a new keystore, change `keystore.properties`, the alias, or `EXPECTED_SHA256.txt`. Every update must carry the same signature.
- NEVER sign a release with the debug key. The Gradle config errors out on purpose if the keystore is missing.
- Keep `applicationId` = `com.dataplug.vtu.app` (must match a client in `google-services.json`). Raise `versionCode` for every release you publish.
- Do not remove `.github/workflows/build.yml` or its signature check. Keep the repository private.
- To ship changes: edit the project, re-zip it as `dataplug_app.zip` (single top-level folder `dataplug_app/`), replace it in the repo, commit.
- Backend: the app talks to the API at the URL in `data/ApiConfig.kt`. The API and admin panel are separate projects.

## Backups
Store `plugbill-permanent.jks` + passwords in at least two private places outside GitHub.

## Google Play
- Upload the **AAB** (artifact DataPlug-AAB-for-PlayStore), not the APK. Use Play App Signing: this permanent key becomes your *upload key*.
- versionCode is set automatically from the GitHub run number (see `VERSION_CODE` in build.yml). Never reuse or lower it.
- Keep targetSdk at the level Google requires (36 since 31 Aug 2026). Raise it yearly; AGP/Gradle must be upgraded with it.
