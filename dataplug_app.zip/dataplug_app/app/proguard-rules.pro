# PlugBill release (R8) rules. Compose, Firebase, WorkManager and Lottie ship their own consumer rules.
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
# Components created by the system from the manifest
-keep class com.example.walletapp.services.** { *; }
-keep class com.example.walletapp.PlugBillApp { *; }
-dontwarn org.jetbrains.annotations.**
