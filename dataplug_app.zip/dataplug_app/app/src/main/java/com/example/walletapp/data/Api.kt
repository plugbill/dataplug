package com.example.walletapp.data

import org.json.JSONObject

private fun jo(vararg p: Pair<String, Any?>) = JSONObject().apply { p.forEach { (k, v) -> if (v != null) put(k, v) } }

/** Ports of AuthAPI / UserAPI / WalletAPI / ServicesAPI / SocialAPI from the web api.ts. Paths and JSON keys are identical. */
object AuthAPI {
    suspend fun register(firstName: String, lastName: String, email: String, phone: String, password: String, pin: String, referralCode: String? = null) =
        ApiClient.post("/auth/register.php", jo("firstName" to firstName, "lastName" to lastName, "email" to email, "phone" to phone,
            "password" to password, "pin" to pin, "referralCode" to referralCode), idempotent = false)

    suspend fun validateRegistration(email: String, phone: String, referralCode: String? = null) =
        ApiClient.post("/auth/validate-registration.php", jo("email" to email, "phone" to phone, "referralCode" to referralCode))

    suspend fun login(email: String, password: String, deviceName: String) =
        ApiClient.post("/auth/login.php", jo("email" to email, "password" to password, "deviceName" to deviceName), idempotent = false)

    /** Master dispatcher otp.php first, then auth/send-otp.php (same failover as the web). */
    suspend fun sendOtp(emailOrPhone: String, type: String = "email_verification"): ApiResult {
        val isEmail = emailOrPhone.contains("@")
        val e = if (isEmail) emailOrPhone else ""; val p = if (isEmail) "" else emailOrPhone
        val r = ApiClient.post("/otp.php", jo("email" to e, "phone" to p, "action" to "send_otp", "type" to type))
        if (r.success) return r
        return ApiClient.post("/auth/send-otp.php", jo("email" to e, "phone" to p, "type" to type))
    }

    suspend fun verifyOtp(emailOrPhone: String, otp: String, type: String = "email_verification"): ApiResult {
        val isEmail = emailOrPhone.contains("@")
        val e = if (isEmail) emailOrPhone else ""; val p = if (isEmail) "" else emailOrPhone
        val r = ApiClient.post("/auth/verify-otp.php", jo("email" to e, "phone" to p, "otp" to otp, "type" to type))
        if (r.success) return r
        return ApiClient.post("/otp.php", jo("action" to "verify_otp", "email" to e, "phone" to p, "otp" to otp, "type" to type))
    }

    suspend fun forgotPassword(email: String) = ApiClient.post("/auth/forgot-password.php", jo("email" to email))

    suspend fun resetPassword(email: String?, otp: String?, resetToken: String?, newPassword: String) =
        ApiClient.post("/auth/reset-password.php", jo("email" to email, "otp" to otp, "token" to resetToken, "resetToken" to resetToken, "newPassword" to newPassword))

    suspend fun logout() { try { ApiClient.post("/auth/logout.php", null) } catch (_: Exception) {} }
}

object UserAPI {
    suspend fun getProfile() = ApiClient.get("/user/profile.php")
    suspend fun updateProfile(p: JSONObject) = ApiClient.post("/user/profile.php", p)
    suspend fun verifyPin(pin: String) = ApiClient.post("/user/verify-pin.php", jo("pin" to pin), idempotent = false)
    suspend fun setPin(newPin: String) = ApiClient.post("/user/set-pin.php", jo("newPin" to newPin), idempotent = false)
    suspend fun getPasscode(email: String, accountId: String) =
        ApiClient.post("/user/get-passcode.php", jo("email" to email, "account_id" to accountId))
    suspend fun setPasscodeStatus(status: String, email: String, accountId: String) =
        ApiClient.post("/user/get-passcode.php", jo("action" to "set_status", "status" to status, "email" to email, "account_id" to accountId))
    suspend fun setPasscode(passcode: String, email: String, accountId: String) =
        ApiClient.post("/user/set-passcode.php", jo("passcode" to passcode, "email" to email, "account_id" to accountId))
    suspend fun verifyPasscode(passcode: String, email: String, accountId: String) =
        ApiClient.post("/user/verify-passcode.php", jo("passcode" to passcode, "email" to email, "account_id" to accountId))
    suspend fun deleteAccount() = ApiClient.post("/user/delete-account.php", null, idempotent = false)
}

object WalletAPI {
    suspend fun getBalance() = ApiClient.get("/wallet/balance.php")
    suspend fun getVirtualAccounts() = ApiClient.get("/wallet/virtual-accounts.php")
    suspend fun generateVirtualAccount(email: String) = ApiClient.post("/wallet/virtual-accounts.php", jo("bank_code" to "9psb", "email" to email))
    suspend fun getHistory(page: Int = 1, limit: Int = 25) = ApiClient.get("/wallet/history.php?page=$page&limit=$limit")
    suspend fun getExpenses() = ApiClient.get("/wallet/expenses.php")
}

object ServicesAPI {
    suspend fun getProviders() = ApiClient.get("/services/providers.php")
    suspend fun buyAirtime(phone: String, network: String, amount: Double, pin: String) =
        ApiClient.post("/services/airtime.php", jo("phone" to phone, "network" to network, "amount" to amount, "pin" to pin), idempotent = false)
    suspend fun buyData(phone: String, network: String, planName: String, planId: String?, planCode: String?, providerPlanId: String?, amount: Double, pin: String) =
        ApiClient.post("/services/data.php", jo("phone" to phone, "network" to network, "planName" to planName, "planId" to planId,
            "planCode" to planCode, "provider_plan_id" to providerPlanId, "amount" to amount, "pin" to pin), idempotent = false)
    suspend fun payElectricity(provider: String, meterNumber: String, amount: Double, pin: String, meterType: String, phone: String?) =
        ApiClient.post("/services/electricity.php", jo("provider" to provider, "disco" to provider, "meterNumber" to meterNumber,
            "amount" to amount, "pin" to pin, "meterType" to meterType, "phone" to phone), idempotent = false)
    suspend fun payCableTv(provider: String, smartcardNumber: String, packageName: String, packageCode: String?, amount: Double, pin: String) =
        ApiClient.post("/services/cable-tv.php", jo("provider" to provider, "smartcardNumber" to smartcardNumber, "packageName" to packageName,
            "packageCode" to packageCode, "amount" to amount, "pin" to pin), idempotent = false)
}

object SocialAPI {
    suspend fun getReferrals() = ApiClient.get("/referrals/stats.php")
    suspend fun claimReferralBonus() = ApiClient.post("/referrals/action.php", jo("action" to "claim"), idempotent = false)
    suspend fun getNotifications() = ApiClient.get("/notifications/list.php")
    suspend fun markNotificationsRead(id: String?) =
        ApiClient.post("/notifications/mark-read.php", jo("id" to id, "markAll" to (id == null), "all" to (id == null)))
    suspend fun deleteNotification(id: String) = ApiClient.post("/notifications/delete.php", jo("id" to id))
    suspend fun clearAllNotifications() = ApiClient.post("/notifications/delete.php", jo("all" to true))
    suspend fun registerDeviceToken(token: String) =
        ApiClient.post("/notifications/register-device.php", jo("device_token" to token, "platform" to "android", "token" to token))
}

object SystemAPI {
    /** GET system/status.php (public). Returns maintenance flag, or null when the server can't be reached. */
    suspend fun maintenanceMode(): Boolean? {
        val r = ApiClient.get("/system/status.php")
        if (!r.success) return null
        return r.obj?.flag("maintenance_mode")
    }
    /** Web calls this on every refresh so pending incoming payments get processed. Result is ignored. */
    suspend fun reprocessWebhooks() { try { ApiClient.get("/webhooks/reprocess.php") } catch (_: Exception) {} }
}
