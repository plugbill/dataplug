package com.example.walletapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight

private class BillCard(
    val title: String,
    val sub: String,
    val icon: Gloss,
    val service: ServiceType? = null,
    val badge: String? = null,
    val disabled: Boolean = false
)

private val billCards = listOf(
    BillCard("Airtime", "Top up any Nigerian network", Gloss.Air, ServiceType.Airtime),
    BillCard("Data", "Bundles for MTN, Airtel, Glo, 9mobile", Gloss.Data, ServiceType.Data),
    BillCard("Electricity", "Prepaid and postpaid meters", Gloss.Elec, ServiceType.Electricity),
    BillCard("TV Subscription", "DStv, GOtv and StarTimes", Gloss.Tv, ServiceType.Tv),
    BillCard("Betting Wallet Funding", "Fund your betting wallet", Gloss.Bet, badge = "Coming Soon"),
    BillCard("Flight Booking", "Book local and international flights", Gloss.Fly, badge = "Coming Soon"),
    BillCard("More Coming Soon", "New services on the way", Gloss.More, disabled = true)
)

private val cardGradients = listOf(
    listOf(Color(0xFFA275FF), Color(0xFF6D28D9)),
    listOf(Color(0xFF8B5CF6), Color(0xFF4C1D95)),
    listOf(Color(0xFF7C3AED), Color(0xFF3B0F8C))
)

/** Bills tab: "Bills & Payments", search, and the large coloured service cards. */
@Composable
fun BillsScreen(onService: (ServiceType) -> Unit) {
    val p = pal()
    var query by remember { mutableStateOf("") }
    val list = billCards.filter { (it.title + " " + it.sub).lowercase().contains(query.trim().lowercase()) }
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(
                start = 20.u(), end = 20.u(),
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 18.u(),
                bottom = 130.u() + navInset
            )
    ) {
        T("Bills & Payments", 28f, FontWeight.Bold, spacing = -0.8f)
        Spacer(Modifier.height(12.u()))
        DPField(query, { query = it }, "Search services", icon = AppIcons.Search)
        Spacer(Modifier.height(16.u()))
        if (list.isEmpty()) {
            T("Nothing found.", 13f, FontWeight.Medium, p.textSecondary, Modifier.fillMaxWidth(), align = androidx.compose.ui.text.style.TextAlign.Center)
        }
        list.forEachIndexed { i, c ->
            BigServiceCard(c, i) {
                val s = c.service
                if (s != null) onService(s) else if (!c.disabled) AppToast.info("${c.title} is coming soon")
            }
            Spacer(Modifier.height(16.u()))
        }
    }
}

@Composable
private fun BigServiceCard(c: BillCard, index: Int, onClick: () -> Unit) {
    val shape = RoundedCornerShape(30.u())
    val g = cardGradients[index % 3]
    Box(
        Modifier
            .fillMaxWidth()
            .staggerIn(index, 30f)
            .graphicsLayer { alpha = if (c.disabled) 0.55f else 1f }
            .pressable(0.96f, onClick)
            .softShadow(shape, AppColors.Accent.copy(alpha = 0.35f), 30.u(), 0.dp, 14.u())
            .clip(shape)
            .background(Brush.linearGradient(g, start = Offset.Zero, end = Offset.Infinite))
            .drawBehind {
                // the translucent disc in the top-right corner
                drawCircle(Color.White.copy(alpha = 0.14f), radius = 95.dp.toPx(), center = Offset(size.width - 65.dp.toPx(), 45.dp.toPx()))
            }
            .heightIn(min = 118.u())
            .padding(horizontal = 22.u(), vertical = 20.u())
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(c.title, 19f, FontWeight.Bold, Color.White, maxLines = 2)
                }
                if (c.badge != null) {
                    Spacer(Modifier.height(5.u()))
                    Box(Modifier.background(Color.White.copy(alpha = 0.22f), CircleShape).padding(horizontal = 10.u(), vertical = 3.u())) {
                        T(c.badge, 10.5f, FontWeight.Bold, Color.White)
                    }
                }
                Spacer(Modifier.height(5.u()))
                T(c.sub, 13f, FontWeight.Medium, Color.White.copy(alpha = 0.85f), lineHeight = 17f)
            }
            Box(Modifier.floating(4f)) { GlossIcon(c.icon, 84.u()) }
        }
    }
}
