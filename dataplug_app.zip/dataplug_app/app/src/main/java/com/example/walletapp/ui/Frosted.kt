package com.example.walletapp.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Records everything drawn by this node (and its children) into [layer], then draws the layer as usual. */
internal fun Modifier.captureInto(layer: GraphicsLayer): Modifier = drawWithContent {
    layer.record { this@drawWithContent.drawContent() }
    drawLayer(layer)
}

/**
 * Screen with a frosted-glass top bar (back button + title).
 *
 * The content scrolls underneath the bar and shows through it blurred (Android 12+; older
 * phones get a solid bar). [content] receives the bar height so it can start below it:
 * add `Spacer(Modifier.height(top))` (or use it as the top content padding of a list).
 *
 * [scrollOffset] should return the current scroll position in px - it only drives the thin
 * divider that fades in once the content has moved under the bar.
 */
@Composable
fun FrostedScreen(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    scrollOffset: () -> Int = { 1000 },
    trailing: (@Composable () -> Unit)? = null,
    rubberBand: Boolean = true,
    content: @Composable (top: Dp) -> Unit
) {
    val p = pal()
    val frosted = Build.VERSION.SDK_INT >= 31
    val headerH = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 76.u()
    val source = rememberGraphicsLayer()
    val blurred = rememberGraphicsLayer()

    Box(modifier.fillMaxSize()) {
        // the page itself (its background is part of what gets blurred, so the bar is never see-through)
        Box(
            Modifier.fillMaxSize()
                .then(if (frosted) Modifier.captureInto(source) else Modifier)
                .background(screenBackground())
        ) {
            // rubber-band over the whole page (screens with a pinned bottom button turn this off and wrap only their scroll area)
            Box(Modifier.fillMaxSize().then(if (rubberBand) Modifier.elastic() else Modifier)) { content(headerH) }
        }

        // the bar
        Box(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(headerH)
                .drawWithContent {
                    // read the scroll position so the bar repaints on every scroll frame
                    scrollOffset()
                    if (frosted) {
                        val r = 26.dp.toPx()
                        blurred.renderEffect = BlurEffect(r, r, TileMode.Clamp)
                        blurred.record { drawLayer(source) }
                        // the blur spills past the layer bounds: keep it strictly inside the bar
                        clipRect(0f, 0f, size.width, size.height) { drawLayer(blurred) }
                        // faint tint in the page's own colour: the bar looks like the page itself until content slides under it
                        drawRect(p.bgTop.copy(alpha = 0.35f))
                    } else {
                        drawRect(p.bgTop.copy(alpha = 0.97f))
                    }
                    drawContent()
                }
        ) {
            Row(
                Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 21.u(), end = 21.u(), bottom = 12.u()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FloatSurface(Modifier.size(52.u()), RoundedCornerShape(18.u()), onBack) { SvgIcon(AppIcons.Back, 22.u(), p.text, 2f) }
                Spacer(Modifier.width(14.u()))
                Box(Modifier.weight(1f)) { T(title, 20f, FontWeight.Bold, maxLines = 1) }
                trailing?.invoke()
            }
        }
    }
}

/**
 * A page whose top [barHeight] is a frosted-glass bar. [content] fills the whole area and scrolls
 * underneath the bar (give it `barHeight` of top padding); it shows through the bar blurred
 * (Android 12+, older phones get a near-solid bar). [bar] is drawn on top of the glass.
 *
 * The page background is part of what gets blurred, so the bar looks exactly like the page until
 * content slides under it. [fadeBottom] makes the glass dissolve softly over its last few dp instead
 * of ending in a hard edge, so the bar never looks like a separate card.
 */
@Composable
fun FrostedBarArea(
    barHeight: Dp,
    modifier: Modifier = Modifier,
    scrollOffset: () -> Int = { 1000 },
    tint: Float = 0.30f,
    blur: Dp = 34.dp,
    fadeBottom: Dp = 0.dp,
    bar: @Composable BoxScope.() -> Unit,
    content: @Composable () -> Unit
) {
    val p = pal()
    val frosted = Build.VERSION.SDK_INT >= 31
    val source = rememberGraphicsLayer()
    val blurred = rememberGraphicsLayer()
    Box(modifier) {
        Box(
            Modifier.fillMaxSize()
                .then(if (frosted) Modifier.captureInto(source) else Modifier)
                .background(screenBackground())
        ) { content() }
        Box(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(barHeight)
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    scrollOffset() // repaint on every scroll frame
                    if (frosted) {
                        val r = blur.toPx()
                        blurred.renderEffect = BlurEffect(r, r, TileMode.Clamp)
                        blurred.record { drawLayer(source) }
                        clipRect(0f, 0f, size.width, size.height) { drawLayer(blurred) }
                        drawRect(p.bgTop.copy(alpha = tint))
                    } else {
                        drawRect(p.bgTop.copy(alpha = 0.97f))
                    }
                    if (fadeBottom.value > 0f) {
                        val f = fadeBottom.toPx().coerceAtMost(size.height)
                        val start = ((size.height - f) / size.height).coerceIn(0f, 1f)
                        drawRect(
                            Brush.verticalGradient(0f to Color.Black, start to Color.Black, 1f to Color.Transparent),
                            blendMode = BlendMode.DstIn
                        )
                    }
                    drawContent()
                },
            content = bar
        )
    }
}
