package com.example.walletapp.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.walletapp.MainActivity
import com.example.walletapp.R

object PlugBillNotificationHelper {

    const val CHANNEL_OTP = "plugbill_otp"
    const val CHANNEL_PAYMENTS = "plugbill_payments"
    const val CHANNEL_BROADCASTS = "plugbill_broadcasts"
    const val CHANNEL_ENGAGEMENT = "plugbill_engagement"

    fun ensureAllNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java) ?: return

            // 1. Security & OTP Verification Channel
            val otpChannel = NotificationChannel(
                CHANNEL_OTP,
                "PlugBill Security & OTP Verification",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Instant verification codes and two-factor authentication alerts"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 100, 250)
                setShowBadge(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(otpChannel)

            // 2. Payments Channel
            val paymentChannel = NotificationChannel(
                CHANNEL_PAYMENTS,
                "Payments & Wallet Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Heads-up alerts for wallet credits and bill payment confirmations"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 200)
                setShowBadge(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC

                val soundResId = context.resources.getIdentifier("payment_chime", "raw", context.packageName)
                if (soundResId != 0) {
                    val soundUri = android.net.Uri.parse("android.resource://${context.packageName}/$soundResId")
                    val audioAttributes = android.media.AudioAttributes.Builder()
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                        .build()
                    setSound(soundUri, audioAttributes)
                }
            }
            manager.createNotificationChannel(paymentChannel)

            // 3. Broadcasts Channel
            val broadcastChannel = NotificationChannel(
                CHANNEL_BROADCASTS,
                "PlugBill System Broadcasts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "General system announcements, service status, and updates"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 150, 100, 150)
                setShowBadge(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(broadcastChannel)

            // 4. Offline Engagement Channel
            val engagementChannel = NotificationChannel(
                CHANNEL_ENGAGEMENT,
                "PlugBill Discounts & Special Offers",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Exclusive data & airtime discounts, cashback alerts, and top-up bonuses"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 150, 100, 150)
                setShowBadge(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(engagementChannel)
        }
    }

    fun showEngagementNotification(context: Context, type: String) {
        ensureAllNotificationChannels(context)

        val (title, body) = when (type) {
            "discount" -> Pair(
                "🎁 Special Discount Today!",
                "Get up to 5% instant discount on your Airtime & Data purchases on PlugBill today!"
            )
            "fast_topup" -> Pair(
                "⚡ Buy Cheap Data & Airtime Instantly!",
                "Enjoy fast & reliable data top-up, electricity bills & cable TV payments on PlugBill."
            )
            "cashback" -> Pair(
                "🔥 Zero Charge Wallet Bonus!",
                "Top up your PlugBill wallet today with zero charges and enjoy instant delivery!"
            )
            else -> Pair(
                "🎉 PlugBill Special Offer",
                "Buy Airtime, Data & Pay Bills easily at the cheapest rates available!"
            )
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("notification_type", "engagement")
            putExtra("engagement_offer", type)
        }

        val notificationId = 8800 + (System.currentTimeMillis() % 1000).toInt()
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val builder = NotificationCompat.Builder(context, CHANNEL_ENGAGEMENT)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(androidx.core.content.ContextCompat.getColor(context, R.color.plugbill_green))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setSound(soundUri)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pendingIntent)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            notificationManager.notify(notificationId, builder.build())
            Log.d("PlugBillNotif", "Posted engagement notification: $title")
        } catch (e: Exception) {
            Log.e("PlugBillNotif", "Error posting notification", e)
        }
    }
}
