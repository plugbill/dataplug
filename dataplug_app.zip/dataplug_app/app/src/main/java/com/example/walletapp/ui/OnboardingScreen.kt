package com.example.walletapp.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import kotlin.math.abs
import kotlinx.coroutines.launch

private class OnboardPage(val icon: Gloss, val title: String, val text: String)

private val pages = listOf(
    OnboardPage(Gloss.Air, "Pay bills instantly", "Airtime, data, electricity and TV in seconds, right from your wallet."),
    OnboardPage(Gloss.Fund, "Fund with ease", "Your own dedicated account number. Transfer once, get credited instantly."),
    OnboardPage(Gloss.Help, "Safe and supported", "Protect every payment with a passcode and fingerprint, track every transaction and reach support any time.")
)

/** Three-step welcome shown the first time the app is opened (DataPlug hero + rounded panel). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onDone: () -> Unit, onLogin: () -> Unit) {
    val p = pal()
    val state = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val page = state.currentPage
    val last = page == pages.size - 1

    Box(Modifier.fillMaxSize().background(p.bgTop)) {
        HeroBackdrop(Modifier.fillMaxWidth().fillMaxHeight(0.62f)) {
            HorizontalPager(state, Modifier.fillMaxSize()) { i ->
                val offset = abs(state.currentPage - i + state.currentPageOffsetFraction).coerceIn(0f, 1f)
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Box(Modifier.scale(1f - 0.2f * offset).alpha(1f - offset).floating(6f)) { GlossIcon(pages[i].icon, 170.u()) }
                }
            }
        }
        if (!last) {
            T(
                "Skip", 14f, FontWeight.SemiBold, Color.White.copy(alpha = 0.9f),
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.u(), end = 14.u()).pressable(onClick = onDone).padding(8.u())
            )
        }
        PanelSurface(Modifier.align(Alignment.BottomCenter)) {
            AnimatedContent(
                targetState = page,
                transitionSpec = {
                    (fadeIn(tween(260, delayMillis = 60)) + slideInHorizontally(spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow)) { it / 6 }) togetherWith
                        (fadeOut(tween(120)) + slideOutHorizontally(tween(180)) { -it / 8 })
                },
                label = "obText"
            ) { i ->
                Column(Modifier.fillMaxWidth().heightIn(min = 138.u())) {
                    T(pages[i].title, 30f, FontWeight.Bold, spacing = -0.8f)
                    Spacer(Modifier.height(8.u()))
                    T(pages[i].text, 15f, FontWeight.Medium, p.textSecondary, lineHeight = 22f)
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 14.u()), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                repeat(pages.size) { i ->
                    val active = page == i
                    val w by animateDpAsState(if (active) 28.u() else 8.u(), spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "dotW")
                    Box(
                        Modifier.padding(horizontal = 3.5.u()).height(8.u()).width(w)
                            .background(if (active) AppColors.Gradient else androidx.compose.ui.graphics.Brush.linearGradient(listOf(p.divider, p.divider)), CircleShape)
                    )
                }
            }
            PrimaryButton(if (last) "Get Started" else "Next") {
                if (last) onDone() else scope.launch { state.animateScrollToPage(page + 1) }
            }
            if (last) {
                Spacer(Modifier.height(10.u()))
                GhostButton("I already have an account", onClick = onLogin)
            }
        }
    }
}
