package com.example.walletapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.walletapp.services.NotificationStore
import kotlinx.coroutines.launch

private class HomeTile(val label: String, val icon: Gloss, val service: ServiceType? = null, val support: Boolean = false)

private val homeTiles = listOf(
    HomeTile("Airtime", Gloss.Air, ServiceType.Airtime),
    HomeTile("Data", Gloss.Data, ServiceType.Data),
    HomeTile("Electricity", Gloss.Elec, ServiceType.Electricity),
    HomeTile("TV Subscription", Gloss.Tv, ServiceType.Tv),
    HomeTile("Scan", Gloss.Scan),
    HomeTile("Contact Support", Gloss.Help, support = true)
)

private fun greeting(): String {
    val h = java.time.LocalTime.now().hour
    return if (h < 12) "Good morning" else if (h < 17) "Good afternoon" else "Good evening"
}

@Composable
fun HomeScreen(
    onFund: () -> Unit,
    onHistory: () -> Unit,
    onBills: () -> Unit,
    onNotifications: () -> Unit,
    onSupport: () -> Unit,
    onService: (ServiceType) -> Unit,
    onLock: () -> Unit
) {
    val ctx = LocalContext.current
    val p = pal()
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val holdPx = with(density) { 72.u().toPx() }
    val maxPx = with(density) { 150.u().toPx() }
    // pull-to-refresh and the "Updated" chip run the same backend refresh as before
    val pull = remember(holdPx, maxPx) {
        PullState(holdPx, maxPx, scope, onTick = { Haptics.tick(ctx) }, onRefresh = {
            if (Network.isOnline(ctx)) com.example.walletapp.data.Sync.refresh(ctx) else AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK)
            Haptics.success(ctx)
        })
    }
    val scroll = rememberScrollState()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(Modifier.fillMaxSize().nestedScroll(pull.connection)) {
        Column(
            Modifier.fillMaxSize()
                .verticalScroll(scroll)
                .padding(horizontal = 20.u())
        ) {
            Spacer(Modifier.height(statusTop + 18.u()))
            TopBar(onNotifications, onLock)
            PullZone(pull, 4.u())
            BalanceBlock(onRefresh = {
                scope.launch {
                    if (Network.isOnline(ctx)) com.example.walletapp.data.Sync.refresh(ctx) else AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK)
                }
            })
            PrimaryButton("Fund Wallet", onClick = onFund)
            Spacer(Modifier.height(14.u()))
            AccountNumberCard(onFund)

            T("More To Love", 19f, FontWeight.Bold, spacing = -0.3f, modifier = Modifier.padding(top = 26.u(), bottom = 14.u()))
            homeTiles.chunked(3).forEachIndexed { r, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.u())) {
                    row.forEachIndexed { c, tile ->
                        Box(Modifier.weight(1f), contentAlignment = Alignment.TopCenter) {
                            TileView(tile, r * 3 + c) {
                                when {
                                    tile.service != null -> onService(tile.service)
                                    tile.support -> onSupport()
                                    else -> AppToast.info("${tile.label} is coming soon")
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.u()))
            }

            Row(Modifier.fillMaxWidth().padding(top = 6.u(), bottom = 8.u()), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                T("Recent Transactions", 19f, FontWeight.Bold, spacing = -0.3f)
                Box(Modifier.pressable(0.93f, onHistory).padding(6.u())) { T("See all", 13.5f, FontWeight.Bold, AppColors.AccentSoft) }
            }
            val recent = allTx.take(3)
            if (recent.isEmpty() && !TxStore.loaded) {
                repeat(3) { TxSkeletonRow() }
            } else if (recent.isEmpty()) {
                T("No transactions yet.", 13f, FontWeight.Medium, p.textSecondary)
            } else {
                recent.forEachIndexed { i, tx -> Box(Modifier.staggerIn(i, 14f)) { TxFlatRow(tx, divider = i < recent.size - 1) { openReceipt(ctx, tx) } } }
            }
            Spacer(Modifier.height(130.u() + navInset))
        }
    }
}

@Composable
private fun TopBar(onNotifications: () -> Unit, onLock: () -> Unit) {
    val p = pal()
    val unread = NotificationStore.unread
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(50.u()).softShadow(CircleShape, p.shadow, 20.u(), 0.dp, 8.u())
                    .background(if (p.dark) Color(0xE0FFFFFF) else Color(0xB3FFFFFF), CircleShape),
                contentAlignment = Alignment.Center
            ) { T(Session.initial, 20f, FontWeight.Bold, AppColors.Accent) }
            Spacer(Modifier.width(12.u()))
            Column(Modifier.weight(1f)) {
                T(greeting(), 12.5f, FontWeight.Medium, p.textSecondary, maxLines = 1)
                T(Session.fullName.ifBlank { Session.firstName.ifBlank { "there" } }, 15.5f, FontWeight.Bold, maxLines = 1)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.u()), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(50.u())) {
                FloatSurface(Modifier.size(50.u()), CircleShape, onNotifications) { SvgIcon(AppIcons.Bell, 21.u(), p.text, 1.9f) }
                if (unread > 0) {
                    Box(
                        Modifier.align(Alignment.TopEnd).offset(x = (-8).u(), y = 9.u()).size(12.u())
                            .background(AppColors.ArrowUp, CircleShape).border(2.dp, p.bgTop, CircleShape)
                    )
                }
            }
            FloatSurface(Modifier.size(50.u()), CircleShape, onLock) { SvgIcon(AppIcons.Lock, 21.u(), p.text, 1.9f) }
        }
    }
}

/** "Wallet Balance": big gradient amount, eye toggle and the "Updated" chip with a spinning refresh icon. */
@Composable
private fun BalanceBlock(onRefresh: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    var spinning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val spin by androidx.compose.animation.core.animateFloatAsState(
        if (spinning) 360f else 0f, androidx.compose.animation.core.tween(800), label = "refreshSpin"
    )
    Column(Modifier.fillMaxWidth().padding(top = 26.u(), bottom = 24.u()), horizontalAlignment = Alignment.CenterHorizontally) {
        T("Wallet Balance", 13f, FontWeight.Medium, p.textSecondary)
        Spacer(Modifier.height(10.u()))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicText(
                text = if (Session.balanceHidden) "\u20A6\u2022\u2022\u2022\u2022\u2022\u2022" else naira(Session.balance),
                style = TextStyle(
                    brush = AppColors.Gradient, fontSize = 40.usp(), fontWeight = FontWeight.Bold,
                    fontFamily = AppFont, letterSpacing = (-1.5f).sp
                ),
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 280.u())
            )
            Box(
                Modifier.size(44.u()).pressable {
                    Session.balanceHidden = !Session.balanceHidden; Session.save(ctx)
                    val hide = if (Session.balanceHidden) 1 else 0
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { try { com.example.walletapp.data.UserAPI.updateProfile(org.json.JSONObject().put("hide_balance", hide)) } catch (_: Exception) {} }
                },
                contentAlignment = Alignment.Center
            ) { SvgIcon(if (Session.balanceHidden) AppIcons.EyeOff else AppIcons.Eye, 22.u(), p.textSecondary, 2f) }
        }
        Spacer(Modifier.height(10.u()))
        val chip = CircleShape
        Row(
            Modifier.height(34.u()).pressable(0.93f) {
                if (!spinning) {
                    spinning = true; onRefresh()
                    scope.launch { kotlinx.coroutines.delay(900); spinning = false }
                }
            }
                .softShadow(chip, p.shadow, 16.u(), 0.dp, 6.u())
                .background(p.surface.copy(alpha = 0.8f), chip)
                .padding(horizontal = 14.u()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.rotate(spin)) { SvgIcon(AppIcons.Refresh, 14.u(), AppColors.Accent, 2.4f) }
            Spacer(Modifier.width(7.u()))
            T(if (spinning) "Refreshing\u2026" else "Updated moments ago", 11f, FontWeight.SemiBold, p.textSecondary, maxLines = 1)
        }
    }
}

/** The 9PSB account number from the old balance card, kept as a compact copy row (same copy / generate behaviour). */
@Composable
private fun AccountNumberCard(onFund: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val p = pal()
    val number = Session.accountNumber
    val shape = RoundedCornerShape(22.u())
    Row(
        Modifier.fillMaxWidth()
            .softShadow(shape, p.shadow, 26.u(), 0.dp, 10.u())
            .background(p.surface.copy(alpha = if (p.dark) 0.8f else 0.72f), shape)
            .border(1.dp, Color.White.copy(alpha = if (p.dark) 0.08f else 0.5f), shape)
            .padding(start = 18.u(), end = 10.u(), top = 10.u(), bottom = 10.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T("9PSB \u2022 ACCOUNT NUMBER", 9.5f, FontWeight.SemiBold, p.textSecondary, spacing = 0.4f)
            Spacer(Modifier.height(2.u()))
            T(number ?: "Not generated yet", 17f, FontWeight.Bold, spacing = if (number != null) 1.5f else 0f, maxLines = 1)
        }
        Box(
            Modifier.height(38.u()).pressable(0.93f) {
                if (number != null) {
                    clip.setText(AnnotatedString(number)); Haptics.tick(ctx)
                    AppToast.success("Account number copied")
                } else onFund()
            }.background(pal().tint, CircleShape).padding(horizontal = 16.u()),
            contentAlignment = Alignment.Center
        ) { T(if (number != null) "Copy" else "Generate", 12.5f, FontWeight.Bold, AppColors.AccentSoft) }
    }
}

/** DataPlug dashboard tile: frosted 28-radius box with a glossy highlight, a floating 3D icon and a label. */
@Composable
private fun TileView(tile: HomeTile, index: Int, onClick: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(28.u())
    Column(Modifier.staggerIn(index, 20f).pressable(0.93f, onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.widthIn(max = 104.u()).fillMaxWidth().aspectRatio(1f)
                .softShadow(shape, p.shadow, 26.u(), 0.dp, 10.u())
                .clip(shape)
                .background(
                    if (p.dark) Brush.linearGradient(listOf(Color(0xA6503A8C), Color(0x80261C40)), Offset.Zero, Offset.Infinite)
                    else Brush.linearGradient(listOf(Color(0xF2FFFFFF), Color(0x73FFFFFF)), Offset.Zero, Offset.Infinite)
                )
                .border(1.dp, if (p.dark) Color(0x1FFFFFFF) else Color(0xE6FFFFFF), shape),
            contentAlignment = Alignment.Center
        ) {
            // glossy highlight over the top half
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.45f).align(Alignment.TopCenter).background(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (p.dark) 0.10f else 0.65f), Color.Transparent))))
            Box(Modifier.floating(4f)) { GlossIcon(tile.icon, 62.u()) }
        }
        Spacer(Modifier.height(10.u()))
        T(tile.label, 13f, FontWeight.SemiBold, maxLines = 1)
    }
}
