package com.example.walletapp.services

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Native replacement for the web app's JavascriptInterface bridge
 * (onUserLogin / onUserLogout / subscribeToTopic / token sync).
 * Topics match the web app: all_users, plugbill_global, user_<ACCOUNT_ID>.
 */
object Push {
    private const val TAG = "PlugBillFCM"
    private const val PREFS = "plugbill_prefs"

    fun ensureFirebase(context: Context): Boolean = try {
        if (FirebaseApp.getApps(context).isEmpty()) FirebaseApp.initializeApp(context)
        FirebaseApp.getApps(context).isNotEmpty()
    } catch (e: Exception) {
        Log.e(TAG, "FirebaseApp initialization failed", e)
        false
    }

    fun registerTopics(context: Context) {
        if (!ensureFirebase(context)) return
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful && !task.result.isNullOrEmpty()) {
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("fcm_token", task.result).apply()
                    FirebaseMessaging.getInstance().subscribeToTopic("all_users")
                    FirebaseMessaging.getInstance().subscribeToTopic("plugbill_global")
                    registerWithBackend(context)
                    val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("user_account_id", null)
                    if (!id.isNullOrEmpty()) FirebaseMessaging.getInstance().subscribeToTopic("user_$id")
                } else {
                    Log.d(TAG, "FCM token sync scheduled: ${task.exception?.message}")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "FCM registration handled safely", e)
        }
    }

    /** Sends the FCM token to notifications/register-device.php (same call the web made after every data sync). Needs a session. */
    fun registerWithBackend(context: Context) {
        if (com.example.walletapp.data.ApiClient.token == null) return
        val token = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("fcm_token", null)
        if (token.isNullOrEmpty()) return
        CoroutineScope(Dispatchers.IO).launch {
            try { com.example.walletapp.data.SocialAPI.registerDeviceToken(token) } catch (_: Exception) {}
        }
    }

    fun onUserLogin(context: Context, accountId: String) {
        if (accountId.isBlank()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("user_account_id", accountId.trim()).apply()
        if (ensureFirebase(context)) {
            try { FirebaseMessaging.getInstance().subscribeToTopic("user_${accountId.trim()}") } catch (e: Exception) { Log.w(TAG, "login subscribe", e) }
        }
        registerTopics(context)
    }

    fun onUserLogout(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = prefs.getString("user_account_id", null)
        prefs.edit().remove("user_account_id").apply()
        if (!id.isNullOrEmpty() && ensureFirebase(context)) {
            try { FirebaseMessaging.getInstance().unsubscribeFromTopic("user_$id") } catch (e: Exception) { Log.w(TAG, "logout unsubscribe", e) }
        }
    }
}
