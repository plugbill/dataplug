package com.example.walletapp

import android.app.Application
import android.util.Log
import com.example.walletapp.services.NotificationStore
import com.example.walletapp.services.PlugBillNotificationHelper
import com.example.walletapp.services.PlugBillNotificationScheduler
import com.example.walletapp.services.Push

/** Same start-up sequence as the web wrapper: Firebase, channels, topics, local engagement alarms. */
class PlugBillApp : Application() {
    companion object { @Volatile var appContext: android.content.Context? = null }
    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext
        com.example.walletapp.ui.Session.load(this)
        try {
            Push.ensureFirebase(this)
            PlugBillNotificationHelper.ensureAllNotificationChannels(this)
            Push.registerTopics(this)
            PlugBillNotificationScheduler.scheduleAll(this)
            NotificationStore.load(this)
        } catch (e: Exception) {
            Log.e("PlugBillApp", "Init error", e)
        }
    }
}
