package com.example.walletapp.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.walletapp.data.ApiClient
import com.example.walletapp.data.SecureStore
import com.example.walletapp.data.dbl
import com.example.walletapp.data.flag
import com.example.walletapp.data.str
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Account/session state. Real data comes from the DataPlug API (see data/Sync.kt, data/AuthFlow.kt).
 * Public property names are unchanged so the UI keeps working. The bearer token and the transaction PIN live in
 * [SecureStore] (Android Keystore AES-GCM); the plain passcode and password are never stored. Passwords, PINs and
 * passcodes that the backend echoes back in user objects are deliberately dropped here.
 */
object Session {
    private const val PREFS = "plugbill_session"
    private var loaded = false

    var loggedIn by mutableStateOf(false)
    var firstName by mutableStateOf("")
    var lastName by mutableStateOf("")
    var email by mutableStateOf("")
    var phone by mutableStateOf("")
    var accountId by mutableStateOf("")
    var balance by mutableDoubleStateOf(0.0)
    var balanceHidden by mutableStateOf(false)
    var accountNumber by mutableStateOf<String?>(null)
    var bankName by mutableStateOf("9 Payment Service Bank")
    var accountName by mutableStateOf("")
    /** Salted SHA-256 of the passcode in the SAME format as the server's passcode_local_key (offline verify). */
    var passcodeHash by mutableStateOf<String?>(null)
    var passcodeEnabled by mutableStateOf(false)
    /** True when the account has a transaction PIN on the server (transaction_pin_set). */
    var payPinHash by mutableStateOf<String?>(null)
    var securityPrompted by mutableStateOf(false)
    var passwordHash by mutableStateOf<String?>(null)
    var biometricEnabled by mutableStateOf(false)
    var twoFactor by mutableStateOf(false)
    var username by mutableStateOf("")
    var referralCode by mutableStateOf("")
    var bonusBalance by mutableDoubleStateOf(0.0)
    var unread by mutableIntStateOf(0)
    var accountStatus by mutableStateOf("active")

    val fullName: String get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "DataPlug User" }
    val initial: String get() = (firstName.ifBlank { email }.firstOrNull() ?: 'D').uppercaseChar().toString()
    val hasPasscode: Boolean get() = passcodeHash != null
    val hasPayPin: Boolean get() = payPinHash != null
    val blocked: Boolean get() = accountStatus in setOf("suspended", "suspension", "banned", "blocked", "terminated", "disabled")

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        SecureStore.init(ctx)
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val tok = SecureStore.get("token")
        ApiClient.token = tok
        loggedIn = tok != null && p.getBoolean("logged_in", false)
        firstName = p.getString("first", "") ?: ""
        lastName = p.getString("last", "") ?: ""
        email = p.getString("email", "") ?: ""
        phone = p.getString("phone", "") ?: ""
        accountId = p.getString("account_id", "") ?: ""
        username = p.getString("username", "") ?: ""
        referralCode = p.getString("ref", "") ?: ""
        balance = p.getString("balance", "0")?.toDoubleOrNull() ?: 0.0
        bonusBalance = p.getString("bonus", "0")?.toDoubleOrNull() ?: 0.0
        balanceHidden = p.getBoolean("hidden", false)
        accountNumber = p.getString("acc_no", null)
        bankName = p.getString("bank_name", null) ?: "9 Payment Service Bank"
        accountName = p.getString("acc_name", "") ?: ""
        passcodeHash = p.getString("pass", null)
        passcodeEnabled = p.getBoolean("pass_on", false)
        payPinHash = if (p.getBoolean("pin_set", false)) "set" else null
        securityPrompted = p.getBoolean("sec_prompted", false)
        passwordHash = p.getString("pw", null)
        biometricEnabled = p.getBoolean("bio_on", false)
        twoFactor = p.getBoolean("2fa", false)
        accountStatus = p.getString("status", "active") ?: "active"
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("logged_in", loggedIn).putString("first", firstName).putString("last", lastName)
            .putString("email", email).putString("phone", phone).putString("account_id", accountId)
            .putString("username", username).putString("ref", referralCode)
            .putString("balance", balance.toString()).putString("bonus", bonusBalance.toString()).putBoolean("hidden", balanceHidden)
            .putString("acc_no", accountNumber).putString("bank_name", bankName).putString("acc_name", accountName)
            .putString("pass", passcodeHash).putBoolean("pin_set", payPinHash != null)
            .putBoolean("sec_prompted", securityPrompted).putString("pw", passwordHash)
            .putBoolean("pass_on", passcodeEnabled).putBoolean("bio_on", biometricEnabled).putBoolean("2fa", twoFactor)
            .putString("status", accountStatus)
            .apply()
    }

    /** Saves a freshly issued token + user (login / OTP login / register). Mirrors saveSession() in api.ts. */
    fun startSession(ctx: Context, token: String, user: JSONObject?, password: String? = null) {
        SecureStore.init(ctx)
        ApiClient.token = token
        SecureStore.put("token", token)
        loggedIn = true
        if (user != null) applyUser(user)
        if (!password.isNullOrEmpty()) passwordHash = hash("pw:$password")
        save(ctx)
        com.example.walletapp.services.Push.onUserLogin(ctx, accountId)
    }

    /** Reads the safe subset of a backend user object. Sensitive echoes (password, pin, passcode) are ignored on purpose. */
    fun applyUser(u: JSONObject) {
        u.str("first_name").ifBlank { u.str("firstName") }.takeIf { it.isNotBlank() }?.let { firstName = it }
        u.str("last_name").ifBlank { u.str("lastName") }.takeIf { it.isNotBlank() }?.let { lastName = it }
        u.str("email").takeIf { it.isNotBlank() }?.let { email = it }
        u.str("phone_number").ifBlank { u.str("phone") }.takeIf { it.isNotBlank() }?.let { phone = it }
        u.str("account_id").ifBlank { u.str("accountId") }.takeIf { it.isNotBlank() }?.let { accountId = it }
        u.str("username").takeIf { it.isNotBlank() }?.let { username = it }
        u.str("referral_code").ifBlank { u.str("referralCode") }.takeIf { it.isNotBlank() }?.let { referralCode = it }
        if (u.has("wallet_balance") && !u.isNull("wallet_balance")) balance = u.dbl("wallet_balance")
        if (u.has("bonus_balance") && !u.isNull("bonus_balance")) bonusBalance = u.dbl("bonus_balance")
        if (u.has("account_status") && !u.isNull("account_status")) accountStatus = u.str("account_status", "active").lowercase()
        if (u.has("transaction_pin_set")) payPinHash = if (u.flag("transaction_pin_set")) "set" else null
        if (u.has("two_factor_enabled")) twoFactor = u.flag("two_factor_enabled")
        // fingerprint is an on-device setting only (kept in SharedPreferences); the server value must never switch it off
        if (u.has("hide_balance") && !u.isNull("hide_balance")) balanceHidden = u.flag("hide_balance")
        // the transaction PIN echoed by profile/verify-otp is kept ONLY encrypted, so fingerprint can authorize a purchase
        u.str("current_pin").takeIf { it.length == 4 }?.let { SecureStore.put("tx_pin", it) }
        u.optJSONArray("virtual_accounts")?.let { applyVirtualAccounts(it) }
    }

    fun applyVirtualAccounts(arr: org.json.JSONArray) {
        val a = arr.optJSONObject(0) ?: return
        val no = a.str("account_number").ifBlank { a.str("accountNumber") }
        if (no.isNotBlank()) {
            accountNumber = no
            bankName = a.str("bank_name").ifBlank { a.str("bankName") }.ifBlank { bankName }
            accountName = a.str("account_name").ifBlank { a.str("accountName") }.ifBlank { accountName }
        }
    }

    /** Local sign-out: clears token, caches, topic subscription. The server logout call is made by the caller. */
    fun logout(ctx: Context) {
        loggedIn = false
        com.example.walletapp.services.Push.onUserLogout(ctx)
        ApiClient.token = null
        SecureStore.clearAll()
        TxStore.clear()
        balance = 0.0; bonusBalance = 0.0; accountNumber = null; accountName = ""; unread = 0
        passcodeHash = null; passcodeEnabled = false; payPinHash = null; passwordHash = null
        biometricEnabled = false; twoFactor = false; accountStatus = "active"
        securityPrompted = false
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        save(ctx)
    }

    // ---- passcode / PIN (same hash format as the web's computePasscodeHash and the server's passcode_local_key) ----
    fun localKey(code: String): String =
        MessageDigest.getInstance("SHA-256").digest("PLUG_SALT_${code}_KEY".toByteArray()).joinToString("") { "%02x".format(it) }

    fun setPasscodeLocal(ctx: Context, code: String, serverKey: String? = null) {
        passcodeHash = serverKey?.takeIf { it.length > 5 } ?: localKey(code); passcodeEnabled = true; save(ctx)
    }
    fun checkPasscode(code: String): Boolean = passcodeHash != null && passcodeHash == localKey(code)

    fun setPayPinLocal(ctx: Context, code: String) { payPinHash = "set"; SecureStore.put("tx_pin", code); save(ctx) }
    /** The PIN used for fingerprint-authorized purchases (null if never entered on this device). */
    fun storedPin(): String? = SecureStore.get("tx_pin")
    fun checkPayPin(code: String): Boolean = storedPin()?.let { it == code } ?: false

    /** In-app re-authentication with the account password typed at the last sign-in on this device. */
    fun checkPassword(pw: String): Boolean = pw.isNotBlank() && passwordHash != null && passwordHash == hash("pw:$pw")

    private fun hash(code: String): String =
        MessageDigest.getInstance("SHA-256").digest(("plugbill:$code").toByteArray()).joinToString("") { "%02x".format(it) }
}
