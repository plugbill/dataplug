package com.example.walletapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp

/** The DataPlug logo tile. */
@Composable
fun AppLogo(modifier: Modifier = Modifier, size: Number = 44) {
    androidx.compose.foundation.Image(
        painter = androidx.compose.ui.res.painterResource(com.example.walletapp.R.drawable.dataplug_logo),
        contentDescription = "DataPlug",
        modifier = modifier.size(size.u())
    )
}
