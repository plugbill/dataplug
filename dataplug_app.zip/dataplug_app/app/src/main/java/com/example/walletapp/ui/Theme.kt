package com.example.walletapp.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import com.example.walletapp.R
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object AppColors {
    /** DataPlug purple (primary #7C3AED). */
    val Accent = Color(0xFF7C3AED)
    val AccentLight = Color(0xFF9F67FF)
    val AccentDeep = Color(0xFF5B21B6)
    val AccentSoft = Color(0xFF8B5CF6)
    val ArrowUp = Color(0xFFE5484D)      // debit
    val ArrowDown = Color(0xFF8B5CF6)    // credit
    /** The DataPlug gradient: 135deg  #9F67FF -> #7C3AED -> #5B21B6. */
    val Gradient: Brush get() = Brush.linearGradient(listOf(AccentLight, Accent, AccentDeep))
}

@Immutable
class Palette(
    val dark: Boolean,
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
    val text: Color,
    val textSecondary: Color,
    val textLight: Color,
    val divider: Color,
    val bar: Color,
    val shadow: Color,
    val highlight: Color,
    val tint: Color,
    val field: Color
)

val LightPalette = Palette(
    false, Color(0xFFF4F2F8), Color(0xFFEFEBF7), Color.White, Color(0xFF16121F), Color(0xFF8A8697),
    Color(0xFFB3AEC4), Color(0xFFE4DFF0), Color(0xFFFFFFFF), Color(0x1A3C1E6E), Color(0xE6FFFFFF),
    Color(0xFFEDE9FE), Color.White
)
val DarkPalette = Palette(
    true, Color(0xFF0D0918), Color(0xFF0D0918), Color(0xFF261C40), Color(0xFFF4F1FF), Color(0xFFA59FB8),
    Color(0xFF6F6890), Color(0xFF34285A), Color(0xFF241A3F), Color(0x66000000), Color(0x0FFFFFFF),
    Color(0x387C3AED), Color(0xFF20173A)
)
val LocalPalette = staticCompositionLocalOf { LightPalette }

@Composable
@ReadOnlyComposable
fun pal(): Palette = LocalPalette.current

/** Outfit (kept from the previous build; DataPlug's Plus Jakarta Sans is not bundled), used for every piece of text in the app (files live in res/font). */
val AppFont: FontFamily = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_medium, FontWeight.Medium),
    Font(R.font.outfit_semibold, FontWeight.SemiBold),
    Font(R.font.outfit_bold, FontWeight.Bold)
)

@Composable
fun screenBackground(): Brush {
    val p = pal()
    return Brush.verticalGradient(listOf(p.bgTop, p.bgBottom))
}

/** One design unit: (min(screenWidth, 430dp) / 360). */
val LocalU = compositionLocalOf { 1.dp }

@Composable
@ReadOnlyComposable
fun Number.u(): Dp = LocalU.current * this.toFloat()

@Composable
@ReadOnlyComposable
fun Number.usp(): TextUnit = (LocalU.current.value * this.toFloat()).sp

@Composable
fun T(
    text: String,
    size: Float,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
    spacing: Float = 0f,
    maxLines: Int = Int.MAX_VALUE,
    underline: Boolean = false,
    lineHeight: Float? = null
) {
    val c = if (color == Color.Unspecified) pal().text else color
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = c,
            fontSize = size.usp(),
            fontWeight = weight,
            fontFamily = AppFont,
            textAlign = align ?: TextAlign.Unspecified,
            letterSpacing = spacing.sp,
            textDecoration = if (underline) TextDecoration.Underline else null,
            lineHeight = lineHeight?.usp() ?: TextUnit.Unspecified
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

/** Press animation: scale to [scaleTo] while pressed. */
fun Modifier.pressable(scaleTo: Float = 0.96f, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) scaleTo else 1f, tween(90), label = "press")
    this
        .graphicsLayer {
            scaleX = s
            scaleY = s
        }
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

/** Blurred shadow that follows any [Shape] (also custom path shapes). */
fun Modifier.softShadow(shape: Shape, shadowColor: Color, blur: Dp, dx: Dp, dy: Dp): Modifier = drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    val androidPath = when (outline) {
        is Outline.Rectangle -> android.graphics.Path().apply { addRect(outline.rect.left, outline.rect.top, outline.rect.right, outline.rect.bottom, android.graphics.Path.Direction.CW) }
        is Outline.Rounded -> android.graphics.Path().apply {
            val r = outline.roundRect
            addRoundRect(
                r.left, r.top, r.right, r.bottom,
                floatArrayOf(
                    r.topLeftCornerRadius.x, r.topLeftCornerRadius.y,
                    r.topRightCornerRadius.x, r.topRightCornerRadius.y,
                    r.bottomRightCornerRadius.x, r.bottomRightCornerRadius.y,
                    r.bottomLeftCornerRadius.x, r.bottomLeftCornerRadius.y
                ),
                android.graphics.Path.Direction.CW
            )
        }
        is Outline.Generic -> outline.path.asAndroidPath()
    }
    drawIntoCanvas { canvas ->
        val androidPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.TRANSPARENT
            setShadowLayer(blur.toPx(), dx.toPx(), dy.toPx(), shadowColor.toArgb())
        }
        canvas.nativeCanvas.drawPath(androidPath, androidPaint)
    }
}

/** White floating neumorphic surface (gray drop shadow + white highlight shadow). */
@Composable
fun FloatSurface(
    modifier: Modifier,
    shape: Shape,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val base = if (onClick != null) modifier.pressable(onClick = onClick) else modifier
    Box(
        modifier = base
            .softShadow(shape, pal().shadow, 26.u(), 0.dp, 10.u())
            .background(pal().surface, shape)
            .border(1.dp, Color.White.copy(alpha = if (pal().dark) 0.08f else 0.55f), shape),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** One segment of a 24x24 icon. */
data class Seg(val d: String, val fill: Boolean = false, val color: Color? = null, val width: Float? = null)

fun icon(vararg d: String): List<Seg> = d.map { Seg(it) }

fun rr(x: Float, y: Float, w: Float, h: Float, r: Float): String =
    "M${x + r} ${y}H${x + w - r}A$r $r 0 0 1 ${x + w} ${y + r}V${y + h - r}A$r $r 0 0 1 ${x + w - r} ${y + h}" +
        "H${x + r}A$r $r 0 0 1 $x ${y + h - r}V${y + r}A$r $r 0 0 1 ${x + r} ${y}Z"

@Composable
fun SvgIcon(segs: List<Seg>, dp: Dp, color: Color, stroke: Float = 2f, modifier: Modifier = Modifier) {
    val parsed = remember(segs) { segs.map { PathParser().parsePathString(it.d).toPath() } }
    Canvas(modifier.size(dp)) {
        val s = this.size.width / 24f
        scale(s, s, pivot = Offset.Zero) {
            segs.forEachIndexed { i, seg ->
                val c = seg.color ?: color
                if (seg.fill) {
                    drawPath(parsed[i], c)
                } else {
                    drawPath(
                        parsed[i], c,
                        style = Stroke(width = seg.width ?: stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
        }
    }
}

/** DataPlug's two drifting purple glows (top-right, bottom-left) behind every tab. */
@Composable
fun DriftingGlow() {
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "glow")
    val d by t.animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(tween(14000, easing = androidx.compose.animation.core.FastOutSlowInEasing), androidx.compose.animation.core.RepeatMode.Reverse),
        label = "drift"
    )
    val glow = AppColors.Accent.copy(alpha = if (pal().dark) 0.30f else 0.22f)
    Canvas(Modifier.fillMaxSize()) {
        val r = 170.dp.toPx()
        drawCircle(
            Brush.radialGradient(listOf(glow, Color.Transparent), center = Offset(size.width + 30.dp.toPx() - 40.dp.toPx() * d, 20.dp.toPx() + 60.dp.toPx() * d), radius = r * (1f + 0.2f * d)),
            radius = r * (1f + 0.2f * d), center = Offset(size.width + 30.dp.toPx() - 40.dp.toPx() * d, 20.dp.toPx() + 60.dp.toPx() * d)
        )
        drawCircle(
            Brush.radialGradient(listOf(glow.copy(alpha = glow.alpha * 0.7f), Color.Transparent), center = Offset(-30.dp.toPx() + 40.dp.toPx() * (1 - d), size.height - 20.dp.toPx() - 50.dp.toPx() * (1 - d)), radius = r),
            radius = r, center = Offset(-30.dp.toPx() + 40.dp.toPx() * (1 - d), size.height - 20.dp.toPx() - 50.dp.toPx() * (1 - d))
        )
    }
}
