package com.example.walletapp.services

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

/** In-app notification inbox (shown on the Notifications screen). Fed by FCM + local events. */
data class AppNotification(
    val id: String,
    val title: String,
    val body: String,
    val type: String,      // wallet | services | security | general
    val time: Long,
    val read: Boolean = false,
    val imageUrl: String? = null   // optional banner sent from the server
)

object NotificationStore {
    private const val PREFS = "plugbill_prefs"
    private const val KEY = "inbox_v1"
    val items = mutableStateListOf<AppNotification>()
    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val raw = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw == null) return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(AppNotification(o.getString("id"), o.getString("title"), o.getString("body"), o.getString("type"), o.getLong("time"), o.optBoolean("read"), o.optString("image").ifBlank { null }))
            }
        } catch (_: Exception) {}
        // the inbox is only for important things: drop old wallet / purchase entries (they live in Transaction history)
        if (items.removeAll { it.type == "wallet" || it.title == "Purchase successful" || it.title == "Wallet credited" }) persist(ctx)
    }

    /** Replaces the server-backed entries (id "srv_<id>") with the latest list from notifications/list.php; local alerts stay. */
    fun syncFromServer(ctx: Context, list: List<AppNotification>) {
        load(ctx)
        val keepLocal = items.filter { !it.id.startsWith("srv_") }
        val merged = (keepLocal + list).sortedByDescending { it.time }.take(100)
        items.clear(); items.addAll(merged)
        persist(ctx)
    }

    /** Server posts (with an optional banner) and security alerts only. Never add transactions here. */
    fun add(ctx: Context, title: String, body: String, type: String, imageUrl: String? = null) {
        load(ctx)
        items.add(0, AppNotification(System.nanoTime().toString(), title, body, type, System.currentTimeMillis(), false, imageUrl))
        while (items.size > 60) items.removeAt(items.lastIndex)
        persist(ctx)
    }

    /** Security alert shown in the bell every time someone signs in. */
    fun addLogin(ctx: Context, email: String) {
        val whenText = java.text.SimpleDateFormat("d MMM yyyy, h:mm a", java.util.Locale.getDefault()).format(java.util.Date())
        val device = (android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + android.os.Build.MODEL).trim()
        add(ctx, "New login to your account", "$email signed in on $device at $whenText. If this wasn't you, change your password and PIN right away.", "security")
    }

    fun markAllRead(ctx: Context) {
        for (i in items.indices) items[i] = items[i].copy(read = true)
        persist(ctx)
    }

    fun markRead(ctx: Context, id: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) { items[i] = items[i].copy(read = true); persist(ctx) }
    }

    fun remove(ctx: Context, id: String) {
        items.removeAll { it.id == id }
        persist(ctx)
    }

    val unread: Int get() = items.count { !it.read }

    private fun persist(ctx: Context) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("type", it.type).put("time", it.time).put("read", it.read).put("image", it.imageUrl ?: ""))
        }
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
