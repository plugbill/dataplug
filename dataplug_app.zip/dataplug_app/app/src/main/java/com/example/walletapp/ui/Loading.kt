package com.example.walletapp.ui

import kotlinx.coroutines.delay
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.clip
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color

/** App-wide loading state. Anything can call show()/hide(), or use [LoadingEffect] inside a composable. */
object AppLoading {
    var count by mutableIntStateOf(0)
    val active: Boolean get() = count > 0
    fun show() { count++ }
    fun hide() { if (count > 0) count-- }
}

/** While [active] is true the full-screen blurred loading layout is shown. Auto-clears when leaving composition. */
@Composable
fun LoadingEffect(active: Boolean) {
    DisposableEffect(active) {
        if (active) AppLoading.show()
        onDispose { if (active) AppLoading.hide() }
    }
}

/** Full-screen scrim + the app logo (max 60x60) squeezing and expanding. The blur itself is applied to the content behind it in AppFrame. */
@Composable
fun LoadingOverlay() {
    val p = pal()
    AnimatedVisibility(AppLoading.active, enter = fadeIn(tween(180)), exit = fadeOut(tween(200))) {
        val t = rememberInfiniteTransition(label = "loadPulse")
        // never larger than the 60x60 logo itself: it squeezes in, then expands back to full size
        val s by t.animateFloat(0.72f, 1f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
        Box(
            Modifier.fillMaxSize()
                .background(if (p.dark) Color(0xFF14151C).copy(alpha = 0.58f) else Color.White.copy(alpha = 0.50f))
                .then(noRipple),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(60.u()), contentAlignment = Alignment.Center) {
                Box(Modifier.scale(s)) { AppLogo(size = 60) }
            }
        }
    }
}

/** Moving highlight for skeleton placeholders. */
@Composable
fun Modifier.shimmer(shape: androidx.compose.ui.graphics.Shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)): Modifier {
    val p = pal()
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-1f, 2f, infiniteRepeatable(tween(1100, easing = androidx.compose.animation.core.LinearEasing)), label = "x")
    val base = if (p.dark) Color(0xFF3A3B4A) else Color(0xFFE3E3E3)
    val hi = if (p.dark) Color(0xFF50526A) else Color(0xFFF7F7F7)
    return this.clip(shape).drawBehind {
        val w = size.width.coerceAtLeast(1f)
        drawRect(
            Brush.linearGradient(
                listOf(base, hi, base),
                start = Offset(w * x - w * 0.5f, 0f), end = Offset(w * x + w * 0.5f, 0f)
            )
        )
    }
}

/** Content that drops in from above after [index] * 90ms. */
@Composable
fun DropIn(index: Int, content: @Composable () -> Unit) {
    var on by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 90L); on = true }
    AnimatedVisibility(
        on,
        enter = fadeIn(tween(320)) + slideInVertically(spring(0.7f, Spring.StiffnessMediumLow)) { -it / 2 }
    ) { content() }
}
