package com.example.walletapp.services

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class PlugBillLocalNotificationWorker(
    private val context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    override fun doWork(): Result {
        return try {
            val prefs = context.getSharedPreferences("plugbill_prefs", Context.MODE_PRIVATE)
            val lastShown = prefs.getLong("last_engagement_notif_time", 0)
            val now = System.currentTimeMillis()

            // Trigger notification if at least 8 hours passed since last engagement message
            if (now - lastShown > 8 * 60 * 60 * 1000) {
                val notifCount = prefs.getInt("engagement_count", 0)
                val type = when (notifCount % 3) {
                    0 -> "discount"
                    1 -> "fast_topup"
                    else -> "cashback"
                }

                PlugBillNotificationHelper.showEngagementNotification(context, type)

                prefs.edit()
                    .putLong("last_engagement_notif_time", now)
                    .putInt("engagement_count", notifCount + 1)
                    .apply()
            }

            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
