package com.example.walletapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Moving placeholder for one flat transaction row while the list loads. */
@Composable
fun TxSkeletonRow() {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.u(), vertical = 12.u()), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.u()).shimmer(RoundedCornerShape(14.u())))
            Spacer(Modifier.width(14.u()))
            Column(Modifier.weight(1f)) {
                Box(Modifier.width(150.u()).height(12.u()).shimmer())
                Spacer(Modifier.height(8.u()))
                Box(Modifier.width(92.u()).height(9.u()).shimmer())
            }
            Spacer(Modifier.width(8.u()))
            Column(horizontalAlignment = Alignment.End) {
                Box(Modifier.width(68.u()).height(13.u()).shimmer())
                Spacer(Modifier.height(8.u()))
                Box(Modifier.width(52.u()).height(14.u()).shimmer(RoundedCornerShape(99.dp)))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(pal().divider))
    }
}
