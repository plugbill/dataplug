package com.example.walletapp.data

import android.util.Base64
import org.json.JSONObject
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * End-to-end encryption of every API call, on top of HTTPS (see api/helpers/secure_channel.php).
 * Per request: fresh P-256 key -> ECDH with the server's public key -> HKDF-SHA256 -> AES-256-GCM.
 * Headers, token and body are inside the encrypted envelope, so a proxy / VPN / MITM only sees random bytes.
 */
object SecureChannel {
    /** The server's public key (X.509 / SPKI, base64). The matching private key never leaves the server. */
    private const val SERVER_PUBLIC_KEY = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEXzLniHHm2nje4aWU0/wCVgUshOy5kFfnqjAnX26TAFq3jMpYwzs3Y84BG3USUBVHWp5I7KGkMX4O7tNuX3qQsA=="

    private val rnd = SecureRandom()
    private val serverKey by lazy {
        KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(SERVER_PUBLIC_KEY, Base64.NO_WRAP)))
    }

    class Prepared(val cipherBody: ByteArray, val ephemeral: String, val ts: String, val nonce: String, val method: String, internal val resKey: ByteArray)

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray = Mac.getInstance("HmacSHA256").run { init(SecretKeySpec(key, "HmacSHA256")); doFinal(data) }

    private fun hkdf64(secret: ByteArray): ByteArray {
        val salt = java.security.MessageDigest.getInstance("SHA-256").digest("PB1-salt".toByteArray())
        val prk = hmac(salt, secret)
        val info = "PBv1".toByteArray()
        val t1 = hmac(prk, info + byteArrayOf(1))
        val t2 = hmac(prk, t1 + info + byteArrayOf(2))
        return t1 + t2
    }

    /** [uri] is path + query exactly as sent on the wire. */
    fun seal(method: String, uri: String, headers: Map<String, String>, body: String): Prepared {
        val kpg = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }
        val kp = kpg.generateKeyPair()
        val secret = KeyAgreement.getInstance("ECDH").run { init(kp.private); doPhase(serverKey, true); generateSecret() }
        val okm = hkdf64(secret)
        val reqKey = okm.copyOfRange(0, 32)
        val resKey = okm.copyOfRange(32, 64)
        val ts = (System.currentTimeMillis() / 1000L + ClockSkew.offsetSeconds).toString()
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val env = JSONObject().put("h", JSONObject(headers as Map<*, *>)).put("b", body).toString()
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(reqKey, "AES"), GCMParameterSpec(128, iv))
        c.updateAAD("PB1|$method|$uri|$ts".toByteArray())
        val ct = c.doFinal(env.toByteArray(Charsets.UTF_8))
        return Prepared(ct, Base64.encodeToString(kp.public.encoded, Base64.NO_WRAP), ts, Base64.encodeToString(iv, Base64.NO_WRAP), method, resKey)
    }

    fun open(p: Prepared, ivB64: String, data: ByteArray): String {
        val iv = Base64.decode(ivB64, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(p.resKey, "AES"), GCMParameterSpec(128, iv))
        c.updateAAD("PB1|RES|${p.ts}|${p.nonce}".toByteArray())
        return String(c.doFinal(data), Charsets.UTF_8)
    }
}

/** Learns the server clock from the HTTP Date header so a wrong phone clock does not break requests. */
object ClockSkew {
    @Volatile var offsetSeconds: Long = 0
    fun learn(serverDateMs: Long) {
        if (serverDateMs > 0) offsetSeconds = (serverDateMs - System.currentTimeMillis()) / 1000L
    }
}
