package com.example.walletapp.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Debug
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.security.KeyStore

/** Switch each protection on or off here. Defaults suit a wallet app. */
object SecurityConfig {
    const val BLOCK_VPN = true
    const val BLOCK_PROXY = true
    const val BLOCK_USER_CERTS = true      // a user-installed CA is how HTTPS inspection tools (Charles, mitmproxy, Burp) work
    const val BLOCK_DEBUGGER = true
    const val BLOCK_HOOKS = true           // Frida, Xposed, LSPosed, Substrate
    const val BLOCK_ROOT = true
    const val BLOCK_EMULATOR = false       // keep false so Play Store pre-launch testing still works
    const val SECURE_WINDOW = true         // no screenshots / screen recording / recents preview
}

enum class Threat(val title: String, val userMessage: String, val hard: Boolean) {
    VPN("VPN detected", "For your security PlugBill does not run while a VPN is on. Turn the VPN off, then try again.", false),
    PROXY("Proxy detected", "A network proxy is active on this phone. Turn it off in Wi-Fi settings, then try again.", false),
    USER_CERT("Unsafe certificate", "A third-party security certificate is installed on this phone, which can be used to read secure traffic. Remove it in Settings > Security, then try again.", false),
    DEBUGGER("Not allowed", "PlugBill cannot run while it is being debugged or inspected.", true),
    HOOK("Not allowed", "PlugBill detected tampering tools on this phone and has stopped to protect your money.", true),
    ROOT("Device not supported", "PlugBill does not run on rooted phones because your wallet could not be kept safe.", true),
    EMULATOR("Device not supported", "PlugBill does not run on emulators.", true)
}

/** Client-side detection. It raises the cost of inspection a lot but cannot be absolute: the real protection is the encrypted channel. */
object SecurityGuard {
    @Volatile private var certCache: Pair<Long, Boolean>? = null

    /** Cheap, safe on any thread: VPN, proxy and inspection certificates only. Used before every API call. */
    fun networkThreat(ctx: Context?): Threat? {
        if (ctx == null) return null
        try {
            if (SecurityConfig.BLOCK_VPN && vpnActive(ctx)) return Threat.VPN
            if (SecurityConfig.BLOCK_PROXY && proxyActive(ctx)) return Threat.PROXY
            if (SecurityConfig.BLOCK_USER_CERTS && userCertInstalled()) return Threat.USER_CERT
        } catch (_: Throwable) {}
        return null
    }

    /** Full scan. Call from a background dispatcher. */
    suspend fun scan(ctx: Context): Threat? = withContext(Dispatchers.IO) {
        try {
            if (SecurityConfig.BLOCK_DEBUGGER && debuggerAttached(ctx)) return@withContext Threat.DEBUGGER
            if (SecurityConfig.BLOCK_HOOKS && hooked()) return@withContext Threat.HOOK
            if (SecurityConfig.BLOCK_ROOT && rooted()) return@withContext Threat.ROOT
            if (SecurityConfig.BLOCK_EMULATOR && emulator()) return@withContext Threat.EMULATOR
        } catch (_: Throwable) {}
        networkThreat(ctx)
    }

    // ---- network ----
    @Suppress("DEPRECATION")
    private fun vpnActive(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm != null) {
            val active = cm.activeNetwork
            val caps = active?.let { cm.getNetworkCapabilities(it) }
            if (caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN))) return true
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true
            }
        }
        val names = listOf("tun", "ppp", "pptp", "tap", "wg", "ipsec", "utun")
        NetworkInterface.getNetworkInterfaces()?.let { e ->
            for (ni in e) if (ni.isUp && names.any { ni.name.lowercase().startsWith(it) }) return true
        }
        return false
    }

    @Suppress("DEPRECATION")
    private fun proxyActive(ctx: Context): Boolean {
        val h = System.getProperty("http.proxyHost") ?: System.getProperty("https.proxyHost")
        if (!h.isNullOrBlank()) return true
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val p = cm?.defaultProxy
        if (p != null && !p.host.isNullOrBlank()) return true
        val host = android.net.Proxy.getDefaultHost()
        return !host.isNullOrBlank()
    }

    private fun userCertInstalled(): Boolean {
        val now = System.currentTimeMillis()
        certCache?.let { if (now - it.first < 60_000) return it.second }
        val found = try {
            val ks = KeyStore.getInstance("AndroidCAStore").apply { load(null) }
            ks.aliases().asSequence().any { it.startsWith("user:") }
        } catch (_: Throwable) { false }
        certCache = now to found
        return found
    }

    // ---- device ----
    private fun debuggerAttached(ctx: Context): Boolean {
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) return true
        if ((ctx.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) return true
        return try {
            File("/proc/self/status").useLines { ls -> ls.firstOrNull { it.startsWith("TracerPid:") }?.substringAfter(':')?.trim()?.toIntOrNull() ?: 0 } > 0
        } catch (_: Throwable) { false }
    }

    private fun hooked(): Boolean {
        val bad = listOf("frida", "gum-js", "gadget", "xposed", "lsposed", "substrate", "edxposed", "riru", "magiskhide")
        try {
            File("/proc/self/maps").useLines { ls -> if (ls.any { l -> val x = l.lowercase(); bad.any { x.contains(it) } }) return true }
        } catch (_: Throwable) {}
        for (c in listOf("de.robv.android.xposed.XposedBridge", "de.robv.android.xposed.XC_MethodHook", "com.saurik.substrate.MS")) {
            try { Class.forName(c); return true } catch (_: Throwable) {}
        }
        try {
            if (Thread.getAllStackTraces().keys.any { val n = it.name.lowercase(); n.contains("gum-js") || n.contains("frida") || n == "gmain" || n == "gdbus" || n.contains("pool-frida") }) return true
        } catch (_: Throwable) {}
        try {
            Socket().use { it.connect(InetSocketAddress("127.0.0.1", 27042), 120); return true }
        } catch (_: Throwable) {}
        return false
    }

    private fun rooted(): Boolean {
        if (Build.TAGS?.contains("test-keys") == true) return true
        val paths = listOf(
            "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/data/local/su", "/su/bin/su", "/system/xbin/daemonsu",
            "/sbin/.magisk", "/data/adb/magisk", "/data/adb/modules", "/cache/magisk.log", "/data/adb/ksu"
        )
        return paths.any { try { File(it).exists() } catch (_: Throwable) { false } }
    }

    private fun emulator(): Boolean {
        val f = Build.FINGERPRINT.lowercase(); val m = Build.MODEL.lowercase(); val h = Build.HARDWARE.lowercase(); val p = Build.PRODUCT.lowercase()
        return f.startsWith("generic") || f.contains("emulator") || m.contains("emulator") || m.contains("android sdk built for") ||
            h.contains("goldfish") || h.contains("ranchu") || p.contains("sdk_gphone") || p == "sdk" || Build.MANUFACTURER.equals("Genymotion", true)
    }
}
