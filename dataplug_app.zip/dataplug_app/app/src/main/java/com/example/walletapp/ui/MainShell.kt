package com.example.walletapp.ui

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

sealed interface Overlay {
    data object None : Overlay
    data object Logout : Overlay
    data object Delete : Overlay
}

/** The four DataPlug tabs, in bar order. */
private class NavItem(val tab: Tab, val label: String, val icon: List<Seg>)

private val navItems = listOf(
    NavItem(Tab.Home, "Home", AppIcons.Home),
    NavItem(Tab.Bills, "Bills", AppIcons.Bills),
    NavItem(Tab.History, "History", AppIcons.Transactions),
    NavItem(Tab.Profile, "Profile", AppIcons.Profile)
)

@Composable
fun MainShell(
    tab: Tab,
    onTab: (Tab) -> Unit,
    dark: Boolean,
    onDark: (Boolean) -> Unit,
    onFund: () -> Unit,
    onNotifications: () -> Unit,
    onExpenses: () -> Unit,
    onSecurity: () -> Unit,
    onReferral: () -> Unit,
    onAccount: () -> Unit,
    onSupport: () -> Unit,
    onService: (ServiceType) -> Unit,
    onLock: () -> Unit,
    onLogout: () -> Unit
) {
    var overlay by remember { mutableStateOf<Overlay>(Overlay.None) }
    // keep the last overlay so its content survives the exit animation
    var shown by remember { mutableStateOf<Overlay>(Overlay.None) }
    if (overlay !is Overlay.None) shown = overlay
    val sheetOpen = overlay !is Overlay.None
    BackHandler(enabled = sheetOpen) { overlay = Overlay.None }

    // backdrop blur behind the log-out sheet (API 31+; older devices fall back to the darker scrim)
    val blurRadius by animateDpAsState(if (sheetOpen && Build.VERSION.SDK_INT >= 31) 24.dp else 0.dp, tween(260), label = "blur")

    Box(Modifier.fillMaxSize().background(screenBackground())) {
        DriftingGlow()
        Box(Modifier.fillMaxSize().blur(blurRadius)) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    // DataPlug screen change: new tab slides in from the side with a quick fade
                    val forward = targetState.ordinal > initialState.ordinal
                    (fadeIn(tween(300, delayMillis = 60)) + slideInHorizontally(spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)) { if (forward) it / 8 else -it / 8 }) togetherWith
                        (fadeOut(tween(130)) + slideOutHorizontally(tween(220)) { if (forward) -it / 10 else it / 10 })
                },
                label = "tabs"
            ) { t ->
                when (t) {
                    Tab.Home -> HomeScreen(
                        onFund = onFund, onHistory = { onTab(Tab.History) }, onBills = { onTab(Tab.Bills) },
                        onNotifications = onNotifications, onSupport = onSupport, onService = onService, onLock = onLock
                    )
                    Tab.Bills -> BillsScreen(onService = onService)
                    Tab.History -> HistoryScreen()
                    Tab.Profile -> ProfileScreen(
                        dark = dark, onDark = onDark, onHistory = { onTab(Tab.History) }, onFund = onFund,
                        onNotifications = onNotifications, onExpenses = onExpenses, onSecurity = onSecurity, onReferral = onReferral,
                        onAccount = onAccount, onSupport = onSupport, onLogout = { overlay = Overlay.Logout }
                    )
                }
            }
        }

        // pill navigation bar slides away while a bottom sheet is open
        AnimatedVisibility(
            visible = !sheetOpen,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(220)),
            exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(180))
        ) {
            PillNav(tab = tab, onTab = { overlay = Overlay.None; onTab(it) })
        }

        // the only bottom sheet on the dashboard: the log-out confirmation
        GlassSheet(visible = sheetOpen, onDismiss = { overlay = Overlay.None }) {
            if (shown is Overlay.Logout) LogoutContent(onCancel = { overlay = Overlay.None }, onConfirm = { overlay = Overlay.None; onLogout() })
        }
    }
}

/**
 * DataPlug bottom bar: a floating glass pill, 78 tall, with a gradient "active" pill that springs
 * between the four tabs (cubic-bezier(.34,1.56,.64,1) in the prototype).
 */
@Composable
private fun PillNav(tab: Tab, onTab: (Tab) -> Unit) {
    val p = pal()
    val shape = CircleShape
    BoxWithConstraints(
        Modifier
            .navigationBarsPadding()
            .padding(start = 14.u(), end = 14.u(), bottom = 14.u())
            .fillMaxWidth()
            .height(78.u())
            .softShadow(shape, Color(0x38280A64), 40.u(), 0.dp, 18.u())
            .background(if (p.dark) p.bar.copy(alpha = 0.94f) else Color.White.copy(alpha = 0.92f), shape)
            .border(1.dp, Color.White.copy(alpha = if (p.dark) 0.10f else 0.6f), shape)
            .padding(8.u())
    ) {
        val slot = maxWidth / navItems.size
        val x by animateDpAsState(slot * tab.ordinal, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow), label = "pillX")
        Box(
            Modifier.offset(x = x).width(slot).fillMaxHeight()
                .softShadow(shape, AppColors.Accent.copy(alpha = 0.45f), 20.u(), 0.dp, 8.u())
                .background(AppColors.Gradient, shape)
        )
        Row(Modifier.fillMaxSize()) {
            navItems.forEach { item ->
                val active = item.tab == tab
                val lift by animateDpAsState(if (active) (-2).dp else 0.dp, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium), label = "lift")
                Column(
                    Modifier.weight(1f).fillMaxHeight().pressable(0.93f) { onTab(item.tab) }.offset(y = lift),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    val c = if (active) Color.White else p.textSecondary
                    SvgIcon(item.icon, 25.u(), c, 1.9f)
                    Spacer(Modifier.height(3.u()))
                    T(item.label, 10.5f, FontWeight.Bold, c, maxLines = 1)
                }
            }
        }
    }
}
