package com.example.walletapp.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight

/**
 * DataPlug hero: 160deg purple gradient (#A275FF -> #7C3AED -> #3B0F8C), two drifting white orbs and two
 * pulsing rings (prototype `.hero`, `.orb`, `.ring`). Content is centred.
 */
@Composable
fun HeroBackdrop(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "hero")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "drift")
    val r1 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "ring1")
    val r2 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, delayMillis = 0, easing = LinearEasing)), label = "ring2")
    Box(
        modifier.clipToBounds().background(
            Brush.linearGradient(listOf(Color(0xFFA275FF), Color(0xFF7C3AED), Color(0xFF3B0F8C)), Offset(0f, 0f), Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY))
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val orb = Color.White.copy(alpha = 0.35f)
            val o1 = Offset(30.dp.toPx() + 40.dp.toPx() * drift, 70.dp.toPx() + 30.dp.toPx() * drift)
            drawCircle(Brush.radialGradient(listOf(orb, Color.Transparent), o1, 130.dp.toPx()), 130.dp.toPx(), o1)
            val o2 = Offset(size.width - 20.dp.toPx() - 40.dp.toPx() * drift, size.height - 10.dp.toPx() - 30.dp.toPx() * drift)
            drawCircle(Brush.radialGradient(listOf(orb, Color.Transparent), o2, 150.dp.toPx()), 150.dp.toPx(), o2)
            val c = Offset(size.width / 2f, size.height / 2f)
            for (ph in listOf(r1, (r2 + 0.5f) % 1f)) {
                val sc = 0.7f + 1.0f * ph
                drawCircle(Color.White.copy(alpha = 0.25f * (1f - ph)), 115.dp.toPx() * sc, c, style = Stroke(1.5.dp.toPx()))
            }
        }
        content()
    }
}

/** White rounded-top panel that overlaps the hero (prototype `.panel`). */
@Composable
fun PanelSurface(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(topStart = 40.u(), topEnd = 40.u())
    Column(
        modifier.fillMaxWidth()
            .softShadow(shape, Color(0x40280A64), 40.u(), 0.dp, (-14).u())
            .background(pal().bgTop, shape)
            .navigationBarsPadding()
            .padding(start = 24.u(), end = 24.u(), top = 30.u(), bottom = 26.u()),
        content = content
    )
}

/** Soft tinted pill button (prototype `.btn.ghost`). */
@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth().height(58.u()).pressable(0.93f, onClick).background(pal().tint, CircleShape),
        contentAlignment = Alignment.Center
    ) { T(text, 16f, FontWeight.Bold, AppColors.AccentSoft) }
}
