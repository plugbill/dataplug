package com.example.walletapp.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.DraggableState
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Rubber-band feel: dragging past the start / end of the content (or dragging a screen that has nothing
 * to scroll) pulls everything inside this modifier along with the finger, with growing resistance,
 * and it springs back on release. A fast fling that hits the edge gives a small bounce.
 *
 * Put it on the PARENT of the scrolling content (anything that comes after it in the modifier chain
 * is what moves). Content before it in the chain (e.g. a background) stays still.
 */
@Composable
fun Modifier.elastic(): Modifier {
    val scope = rememberCoroutineScope()
    val maxPx = with(LocalDensity.current) { 130.dp.toPx() }
    val state = remember { ElasticState(scope, maxPx) }
    return this
        .nestedScroll(state.connection)
        .draggable(
            state = state.dragState,
            orientation = Orientation.Vertical,
            onDragStarted = { state.cancel() },
            onDragStopped = { state.release() }
        )
        .graphicsLayer { translationY = state.pull }
}

private class ElasticState(private val scope: CoroutineScope, private val maxPx: Float) {
    var pull by mutableFloatStateOf(0f)
    private var job: Job? = null

    fun cancel() { job?.cancel(); job = null }

    /** Moves the content by [delta] of finger travel, with resistance that grows as it stretches. */
    fun add(delta: Float) {
        val resist = (1f - abs(pull) / maxPx).coerceIn(0.06f, 1f) * 0.55f
        pull = (pull + delta * resist).coerceIn(-maxPx, maxPx)
    }

    fun release() {
        if (pull == 0f) return
        job?.cancel()
        job = scope.launch {
            animate(
                initialValue = pull, targetValue = 0f,
                animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow)
            ) { v, _ -> pull = v }
        }
    }

    val dragState = DraggableState { add(it) }

    val connection = object : NestedScrollConnection {
        // finger moving back toward rest while stretched: unwind the stretch before the list scrolls
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
            if (source != NestedScrollSource.UserInput || pull == 0f) return Offset.Zero
            val d = available.y
            if ((pull > 0f && d < 0f) || (pull < 0f && d > 0f)) {
                cancel()
                val back = if (pull > 0f) maxOf(d, -pull) else minOf(d, -pull)
                pull += back
                return Offset(0f, back)
            }
            return Offset.Zero
        }

        // the list is at its edge (or has nothing to scroll): whatever is left stretches the content
        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
            val d = available.y
            if (d == 0f) return Offset.Zero
            if (source == NestedScrollSource.UserInput) {
                cancel()
                add(d)
            } else {
                // fling that ran into the edge: small bounce
                pull = (pull + d * 0.10f).coerceIn(-maxPx * 0.5f, maxPx * 0.5f)
                release()
            }
            return Offset(0f, d)
        }

        override suspend fun onPreFling(available: Velocity): Velocity {
            if (pull != 0f) { release(); return available }
            return Velocity.Zero
        }

        override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
            release()
            return Velocity.Zero
        }
    }
}
