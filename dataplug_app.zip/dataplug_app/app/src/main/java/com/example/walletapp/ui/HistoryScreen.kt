package com.example.walletapp.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val FILTERS = listOf("All", "Airtime", "Data", "Electricity", "TV", "Funding", "Successful", "Failed")

private fun matches(tx: Tx, filter: String, q: String): Boolean {
    val okFilter = when (filter) {
        "All" -> true
        "Airtime" -> tx.kind == Kind.Airtime
        "Data" -> tx.kind == Kind.Data
        "Electricity" -> tx.kind == Kind.Electricity
        "TV" -> tx.kind == Kind.Tv
        "Funding" -> tx.kind == Kind.Funding
        "Successful" -> tx.status.uppercase() == "SUCCESSFUL"
        else -> tx.status.uppercase() !in listOf("SUCCESSFUL", "PENDING")
    }
    if (!okFilter) return false
    val needle = q.trim().lowercase()
    return needle.isEmpty() || (tx.reference + " " + tx.recipient + " " + tx.title + " " + tx.service).lowercase().contains(needle)
}

/** "Today", "Yesterday" or "12 Oct 2026" from the transaction's short date. */
private fun dayLabel(tx: Tx): String = try {
    val fmt = java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy", java.util.Locale.ENGLISH)
    val d = java.time.LocalDate.parse(tx.shortDate, fmt)
    val today = java.time.LocalDate.now()
    when (d) {
        today -> "Today"
        today.minusDays(1) -> "Yesterday"
        else -> d.format(java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy", java.util.Locale.ENGLISH))
    }
} catch (_: Exception) { tx.day.ifBlank { tx.shortDate } }

/** History tab: search, filter chips, day-grouped flat list. Same data and paging (pull up for 20 more) as before. */
@Composable
fun HistoryScreen() {
    val p = pal()
    val ctx = LocalContext.current
    val lazy = rememberLazyListState()
    val pull = rememberPullUpState()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    val shown = allTx.filter { matches(it, filter, query) }

    Box(
        Modifier.fillMaxSize().pullUpToLoad(pull, enabled = TxStore.hasMore && TxStore.loaded) {
            com.example.walletapp.data.Sync.loadMoreHistory()
        }
    ) {
        LazyColumn(
            Modifier.fillMaxSize().graphicsLayer { translationY = -pull.offset.value },
            state = lazy,
            contentPadding = PaddingValues(
                start = 20.u(), end = 20.u(),
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 18.u(),
                bottom = 130.u() + navInset
            )
        ) {
            item {
                T("History", 28f, FontWeight.Bold, spacing = -0.8f)
                Spacer(Modifier.height(12.u()))
                DPField(query, { query = it }, "Search reference, phone or type", icon = AppIcons.Search)
                Spacer(Modifier.height(12.u()))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.u())) {
                    FILTERS.forEach { f -> Chip(f, filter == f) { filter = f } }
                }
                Spacer(Modifier.height(8.u()))
            }
            if (!TxStore.loaded && allTx.isEmpty()) {
                items(8) { TxSkeletonRow() }
            } else if (shown.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 44.u()), horizontalAlignment = Alignment.CenterHorizontally) {
                        GlossIcon(Gloss.Tv, 80.u())
                        Spacer(Modifier.height(10.u()))
                        T("No transactions found", 19f, FontWeight.Bold)
                        Spacer(Modifier.height(4.u()))
                        T(if (allTx.isEmpty()) "No transactions yet" else "Try a different search or filter.", 13f, FontWeight.Medium, p.textSecondary)
                    }
                }
            } else {
                var last = ""
                shown.forEachIndexed { i, tx ->
                    val label = dayLabel(tx)
                    val header = label != last
                    last = label
                    if (header) item(key = "h$i$label") {
                        T(label, 13f, FontWeight.Bold, p.textSecondary, Modifier.padding(top = 14.u(), bottom = 6.u()))
                    }
                    item(key = "t${tx.reference}$i") { TxFlatRow(tx) { openReceipt(ctx, tx) } }
                }
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 16.u()), contentAlignment = Alignment.Center) {
                        T(
                            if (TxStore.hasMore) "Pull up to load ${TxStore.PAGE_SIZE} more" else "You're all caught up",
                            11f, FontWeight.Medium, p.textSecondary
                        )
                    }
                }
            }
        }
        PullUpFooter(pull, TxStore.PAGE_SIZE, Modifier.align(Alignment.BottomCenter).padding(bottom = 96.u() + navInset))
    }
}
