package com.example.walletapp.data

import android.content.Context
import com.example.walletapp.ui.Session
import com.example.walletapp.ui.TxMapper
import com.example.walletapp.ui.TxStore
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject

enum class SyncResult { OK, EXPIRED, OFFLINE, BLOCKED }

/** Equivalent of fetchCompleteUserData() + applyUserDataset() in the web app. Safe to call often; never logs the user out on network errors. */
object Sync {
    var lastBlockMessage: String? = null
    private val mutex = kotlinx.coroutines.sync.Mutex()

    suspend fun refresh(ctx: Context): SyncResult {
        if (ApiClient.token == null) return SyncResult.EXPIRED
        if (!mutex.tryLock()) return SyncResult.OK // a refresh is already running
        try {
            val email = Session.email; val acc = Session.accountId
            val (profile, balance, history, referrals, passcode) = coroutineScope {
                val a = async { UserAPI.getProfile() }
                val b = async { WalletAPI.getBalance() }
                val c = async { WalletAPI.getHistory(1, TxStore.PAGE_SIZE) }
                val d = async { SocialAPI.getReferrals() }
                val e = async { UserAPI.getPasscode(email, acc) }
                Five(a.await(), b.await(), c.await(), d.await(), e.await())
            }
            if (profile.isUnauthorized || balance.isUnauthorized) {
                Session.logout(ctx)
                return SyncResult.EXPIRED
            }
            if (profile.statusCode == 403 || balance.statusCode == 403) {
                val m = (if (profile.statusCode == 403) profile.message else balance.message)
                Session.accountStatus = if (m.contains("ban", true)) "banned" else if (m.contains("suspend", true)) "suspended" else "disabled"
                lastBlockMessage = m
                return SyncResult.BLOCKED
            }
            if (!profile.success && !balance.success && profile.statusCode >= 500) return SyncResult.OFFLINE

            profile.obj?.optJSONObject("user")?.let { Session.applyUser(it) }
            if (balance.success) balance.obj?.let { b ->
                Session.balance = b.dbl("balance", Session.balance)
                Session.bonusBalance = b.dbl("bonusBalance", Session.bonusBalance)
                b.optJSONArray("virtualAccounts")?.let { Session.applyVirtualAccounts(it) }
            }
            if (history.success) {
                val h = history.obj
                val arr = h?.optJSONArray("transactions") ?: history.arr
                if (arr != null) {
                    val list = (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { try { TxMapper.fromJson(it) } catch (_: Exception) { null } } }
                    val pg = h?.optJSONObject("pagination")
                    TxStore.mergeFirst(list, pg != null && pg.optInt("page", 1) < pg.optInt("totalPages", 1))
                }
            }
            if (referrals.success) referrals.obj?.let { r ->
                r.str("referralCode").takeIf { it.isNotBlank() }?.let { Session.referralCode = it }
            }
            if (passcode.success) passcode.obj?.let { AuthFlow.applyPasscodeInfo(ctx, it) }
            Session.save(ctx)
            com.example.walletapp.services.Push.registerWithBackend(ctx)
            try { pullNotifications(ctx) } catch (_: Exception) {}
            return if (Session.blocked) SyncResult.BLOCKED else SyncResult.OK
        } finally { TxStore.loaded = true; mutex.unlock() }
    }

    suspend fun pullNotifications(ctx: Context) {
        val r = SocialAPI.getNotifications()
        if (!r.success) return
        val arr = r.obj?.optJSONArray("notifications") ?: return
        val list = (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val t = try { java.time.LocalDateTime.parse(o.str("created_at").replace(' ', 'T')).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() } catch (_: Exception) { System.currentTimeMillis() }
            val type = when (o.str("type").lowercase()) { "security" -> "security"; "wallet", "payment", "funding" -> "wallet"; "broadcast", "general", "system", "engagement" -> "general"; else -> "services" }
            com.example.walletapp.services.AppNotification("srv_" + o.str("id"), o.str("title", "PlugBill Notification"), o.str("message").ifBlank { o.str("body") }, type, t, o.flag("is_read"), o.str("image_url").ifBlank { null })
        }
        com.example.walletapp.services.NotificationStore.syncFromServer(ctx, list)
    }

    /** Loads the next history page (History screen pagination). */
    suspend fun loadMoreHistory() {
        if (!TxStore.hasMore || TxStore.loadingMore) return
        TxStore.loadingMore = true
        try {
            val next = TxStore.page + 1
            val r = WalletAPI.getHistory(next, TxStore.PAGE_SIZE)
            if (r.success) {
                val arr = r.obj?.optJSONArray("transactions") ?: return
                val list = (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { try { TxMapper.fromJson(it) } catch (_: Exception) { null } } }
                val pg = r.obj?.optJSONObject("pagination")
                TxStore.append(list, next, pg != null && pg.optInt("page", next) < pg.optInt("totalPages", next))
            }
        } finally { TxStore.loadingMore = false }
    }

    private data class Five(val a: ApiResult, val b: ApiResult, val c: ApiResult, val d: ApiResult, val e: ApiResult)
}
