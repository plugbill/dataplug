package com.example.walletapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

/**
 * DataPlug's glossy 3D purple icons (the `G` set in the prototype's app.js), drawn on a 64 x 64 canvas.
 * Gradients follow the prototype: pg = purple, ps = shine, pw = white, pd = deep purple, pr = radial orb.
 */
enum class Gloss { Air, Data, Elec, Tv, Scan, Help, Bet, Fly, Fund, Bills, Moon, More }

private enum class Grad { PG, PS, PW, PD, PR }

private class Prim(
    val d: String,
    val fill: Grad? = null,
    val solid: Color? = null,
    val stroke: Grad? = null,
    val strokeSolid: Color? = null,
    val sw: Float = 0f
)

private fun circ(cx: Float, cy: Float, r: Float) = "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"
private fun ell(cx: Float, cy: Float, rx: Float, ry: Float) = "M${cx - rx} ${cy}a$rx $ry 0 1 0 ${2 * rx} 0a$rx $ry 0 1 0 ${-2 * rx} 0z"
private fun fillP(d: String, g: Grad) = Prim(d, fill = g)
private fun strokeP(d: String, g: Grad, w: Float) = Prim(d, stroke = g, sw = w)
private val White = Color.White

private val SET: Map<Gloss, List<Prim>> = mapOf(
    Gloss.Air to listOf(
        fillP(rr(17f, 5f, 30f, 54f, 8f), Grad.PG), fillP(rr(17f, 5f, 30f, 26f, 8f), Grad.PS), fillP(rr(21f, 11f, 22f, 40f, 5f), Grad.PW),
        fillP("M32 20l-8 9h5v10h6V29h5z", Grad.PG)
    ),
    Gloss.Data to listOf(
        fillP(circ(32f, 32f, 26f), Grad.PR),
        Prim("M15 29a24 24 0 0 1 34 0M22 36a15 15 0 0 1 20 0", strokeSolid = White, sw = 4.5f),
        Prim(circ(32f, 45f, 3.5f), solid = White),
        Prim(ell(25f, 17f, 11f, 5f), solid = White.copy(alpha = 0.3f))
    ),
    Gloss.Elec to listOf(
        fillP("M37 3 13 37h15l-4 24 27-35H36z", Grad.PG), fillP("M37 3 13 37h15z", Grad.PS),
        Prim("M37 3 24 22", strokeSolid = White.copy(alpha = 0.6f), sw = 2f)
    ),
    Gloss.Tv to listOf(
        fillP(rr(5f, 10f, 54f, 36f, 9f), Grad.PG), fillP(rr(5f, 10f, 54f, 18f, 9f), Grad.PS), fillP(rr(10f, 15f, 44f, 26f, 5f), Grad.PW),
        fillP("M28 22l11 6-11 6z", Grad.PG), fillP(rr(20f, 49f, 24f, 7f, 3.5f), Grad.PD)
    ),
    Gloss.Scan to listOf(
        strokeP("M7 21V13a6 6 0 0 1 6-6h8M43 7h8a6 6 0 0 1 6 6v8M57 43v8a6 6 0 0 1-6 6h-8M21 57h-8a6 6 0 0 1-6-6v-8", Grad.PG, 6f),
        fillP(rr(17f, 17f, 30f, 30f, 7f), Grad.PW),
        fillP(rr(21f, 21f, 9f, 9f, 2f), Grad.PG), fillP(rr(34f, 21f, 9f, 9f, 2f), Grad.PG), fillP(rr(21f, 34f, 9f, 9f, 2f), Grad.PG),
        fillP("M34 34h4v4h-4z", Grad.PG), fillP("M39 39h4v4h-4z", Grad.PG)
    ),
    Gloss.Help to listOf(
        strokeP("M12 36v-6a20 20 0 0 1 40 0v6", Grad.PG, 7f),
        fillP(rr(6f, 34f, 13f, 19f, 6.5f), Grad.PG), fillP(rr(45f, 34f, 13f, 19f, 6.5f), Grad.PG),
        strokeP("M51 53q0 7-13 7", Grad.PD, 4f), fillP(circ(36f, 60f, 3.5f), Grad.PW)
    ),
    Gloss.Bet to listOf(
        fillP(circ(32f, 32f, 27f), Grad.PR),
        Prim(circ(32f, 32f, 18f), strokeSolid = White.copy(alpha = 0.8f), sw = 3f),
        fillP(circ(32f, 32f, 10f), Grad.PW),
        Prim("M32 27v10M27 32h10", strokeSolid = Color(0xFF7C3AED), sw = 3.5f)
    ),
    Gloss.Fly to listOf(
        fillP("M5 30 59 7 41 57 31 39z", Grad.PG), fillP("M5 30 59 7 31 39z", Grad.PW), fillP("M31 39l-1 15 9-10z", Grad.PD)
    ),
    Gloss.Fund to listOf(
        fillP(rr(5f, 13f, 54f, 40f, 10f), Grad.PG), fillP(rr(5f, 13f, 54f, 20f, 10f), Grad.PS), fillP(rr(37f, 27f, 22f, 15f, 7.5f), Grad.PW),
        fillP(circ(46f, 34.5f, 3f), Grad.PG)
    ),
    Gloss.Bills to listOf(
        fillP("M14 5h26l13 13v34a7 7 0 0 1-7 7H14a7 7 0 0 1-7-7V12a7 7 0 0 1 7-7z", Grad.PW),
        fillP("M40 5l13 13H46a6 6 0 0 1-6-6z", Grad.PD),
        fillP(rr(15f, 27f, 16f, 5f, 2.5f), Grad.PG), fillP(rr(15f, 37f, 30f, 5f, 2.5f), Grad.PG), fillP(rr(15f, 47f, 22f, 5f, 2.5f), Grad.PG)
    ),
    Gloss.Moon to listOf(
        fillP("M42 5a27 27 0 1 0 17 39A23 23 0 0 1 42 5z", Grad.PG), fillP("M42 5a27 27 0 0 0-30 16 24 24 0 0 1 30-16z", Grad.PS)
    ),
    Gloss.More to listOf(
        fillP(circ(32f, 32f, 27f), Grad.PR),
        Prim(circ(19f, 32f, 4f), solid = White), Prim(circ(32f, 32f, 4f), solid = White), Prim(circ(45f, 32f, 4f), solid = White)
    )
)

private val C_A78 = Color(0xFFA78BFA)
private val C_7C3 = Color(0xFF7C3AED)
private val C_5B2 = Color(0xFF5B21B6)

private fun brushFor(g: Grad, r: Rect): Brush = when (g) {
    Grad.PG -> Brush.verticalGradient(0f to C_A78, 0.5f to C_7C3, 1f to C_5B2, startY = r.top, endY = r.bottom)
    Grad.PS -> Brush.verticalGradient(listOf(White.copy(alpha = 0.55f), White.copy(alpha = 0f)), startY = r.top, endY = r.bottom)
    Grad.PW -> Brush.linearGradient(listOf(White, Color(0xFFD9CCFB)), start = r.topLeft, end = r.bottomRight)
    Grad.PD -> Brush.linearGradient(listOf(C_7C3, Color(0xFF3B0F8C)), start = r.topLeft, end = r.bottomRight)
    Grad.PR -> Brush.radialGradient(
        0f to Color(0xFFC4B0FF), 0.5f to C_7C3, 1f to Color(0xFF4C1D95),
        center = Offset(r.left + r.width * 0.3f, r.top + r.height * 0.25f), radius = maxOf(r.width, r.height) * 0.9f
    )
}

/** One glossy DataPlug icon, [size] square. */
@Composable
fun GlossIcon(kind: Gloss, size: Dp, modifier: Modifier = Modifier) {
    val paths = remember(kind) { SET.getValue(kind).map { it to PathParser().parsePathString(it.d).toPath() } }
    Canvas(modifier.size(size)) {
        val k = this.size.width / 64f
        scale(k, k, pivot = Offset.Zero) {
            for ((p, path) in paths) {
                val b = path.getBounds()
                when {
                    p.fill != null -> drawPath(path, brushFor(p.fill, b))
                    p.solid != null -> drawPath(path, p.solid)
                    p.stroke != null -> drawPath(path, brushFor(p.stroke, b), style = Stroke(p.sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    p.strokeSolid != null -> drawPath(path, p.strokeSolid, style = Stroke(p.sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}
