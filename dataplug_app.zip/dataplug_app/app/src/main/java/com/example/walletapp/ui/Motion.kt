package com.example.walletapp.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay

/** DataPlug staggered entrance (prototype: `.tile`, `.bigc`, `.txr` with a 55 ms step): fade, rise and spring-scale in. */
fun Modifier.staggerIn(index: Int, rise: Float = 22f): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(minOf(index, 14) * 55L)
        a.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow))
    }
    val u = LocalU.current
    graphicsLayer {
        val v = a.value
        alpha = v.coerceIn(0f, 1f)
        translationY = (1f - v) * rise * u.toPx()
        val sc = 0.8f + 0.2f * v
        scaleX = sc
        scaleY = sc
    }
}

/** Slow 4 s up-and-down float used by the tiles and service-card icons (`@keyframes flt`). */
fun Modifier.floating(amount: Float = 4f, offsetMs: Int = 0): Modifier = composed {
    val t = rememberInfiniteTransition(label = "float")
    val v by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2000, delayMillis = 0, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "floatV"
    )
    val u = LocalU.current
    graphicsLayer { translationY = -(v * amount) * u.toPx() }
}
