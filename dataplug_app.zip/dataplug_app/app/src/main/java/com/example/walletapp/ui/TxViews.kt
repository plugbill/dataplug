package com.example.walletapp.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.walletapp.ReceiptActivity

/**
 * Transaction leading icon: the network / provider logo (MTN, Airtel, DStv...) for airtime, data and TV,
 * otherwise a purple icon tile (wallet funding, payment received) or an amber one (electricity).
 * The DataPlug app logo is never used here.
 */
@Composable
fun TxIcon(tx: Tx, size: Number = 52, corner: Number = 16) {
    val p = pal()
    val shape = RoundedCornerShape(corner.u())
    val logo = tx.logo?.takeIf { it != Logos.DataPlug }
    if (logo != null) {
        Box(Modifier.size(size.u()).softShadow(shape, p.shadow, 10.u(), 0.dp, 4.u())) {
            Image(
                painter = painterResource(logo),
                contentDescription = tx.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size.u()).clip(shape)
            )
        }
    } else {
        // DataPlug glossy 3D icon for the service type
        GlossIcon(txGloss(tx), size.u())
    }
}

fun txGloss(tx: Tx): Gloss = when (tx.kind) {
    Kind.Airtime -> Gloss.Air
    Kind.Data -> Gloss.Data
    Kind.Electricity -> Gloss.Elec
    Kind.Tv -> Gloss.Tv
    Kind.Funding -> Gloss.Fund
}

/** Pill badge: Successful (purple tint), Pending (amber), Failed (red). */
@Composable
fun StatusBadge(status: String) {
    val (label, fg, bg) = when (status.uppercase()) {
        "SUCCESSFUL" -> Triple("Successful", AppColors.AccentSoft, pal().tint)
        "PENDING" -> Triple("Pending", Color(0xFFB7791F), Color(0x26F59E0B))
        else -> Triple("Failed", AppColors.ArrowUp, Color(0x26E5484D))
    }
    Box(Modifier.background(bg, CircleShape).padding(horizontal = 10.u(), vertical = 3.u())) {
        T(label, 10.5f, FontWeight.Bold, fg, maxLines = 1)
    }
}

/** Flat DataPlug transaction row: icon, title + recipient/time, signed amount + status badge, hairline under it. */
@Composable
fun TxFlatRow(tx: Tx, divider: Boolean = true, onClick: () -> Unit) {
    val p = pal()
    Column(Modifier.fillMaxWidth().pressable(0.98f, onClick)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.u(), horizontal = 4.u()), verticalAlignment = Alignment.CenterVertically) {
            TxIcon(tx, size = 44, corner = 14)
            Spacer(Modifier.width(14.u()))
            Column(Modifier.weight(1f)) {
                T(tx.title, 13.5f, FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.height(2.u()))
                T(listOf(tx.recipient, tx.time).filter { it.isNotBlank() && it != "now" }.joinToString(" \u00B7 "), 11.5f, FontWeight.Medium, p.textSecondary, maxLines = 1)
            }
            Spacer(Modifier.width(8.u()))
            Column(horizontalAlignment = Alignment.End) {
                T(
                    (if (tx.incoming) "+" else "-") + "\u20A6" + tx.amount, 13.5f, FontWeight.Bold,
                    if (tx.incoming) AppColors.ArrowDown else AppColors.ArrowUp, maxLines = 1
                )
                Spacer(Modifier.height(5.u()))
                StatusBadge(tx.status)
            }
        }
        if (divider) Box(Modifier.fillMaxWidth().height(1.dp).background(p.divider))
    }
}

/** Opens the receipt screen (its own Activity) for a transaction. */
fun openReceipt(ctx: Context, tx: Tx) {
    ctx.startActivity(Intent(ctx, ReceiptActivity::class.java).putExtra(ReceiptActivity.EXTRA_REF, tx.reference))
    (ctx as? android.app.Activity)?.overridePendingTransition(com.example.walletapp.R.anim.fade_in_soft, com.example.walletapp.R.anim.fade_out_soft)
}
