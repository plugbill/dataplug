package com.example.walletapp.data

import android.content.Context
import android.os.Build
import com.example.walletapp.ui.Session
import org.json.JSONObject

sealed class LoginOutcome {
    object Ok : LoginOutcome()
    object NeedOtp : LoginOutcome()
    class Fail(val message: String) : LoginOutcome()
    class Blocked(val message: String, val status: String = "disabled") : LoginOutcome()
}

/** Login, OTP, registration, passcode unlock. Same call order and same endpoints as the web App.tsx handlers. */
object AuthFlow {
    /** Password typed at login, kept in memory only while the 2FA OTP step is pending. */
    private var pendingPassword: String? = null
    private val blockedStates = setOf("suspended", "banned", "blocked", "terminated", "disabled")

    fun deviceName() = "PlugBill Android (" + (Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL).trim() + ")"

    suspend fun login(ctx: Context, email: String, password: String): LoginOutcome {
        val r = AuthAPI.login(email.trim(), password, deviceName())
        if (!r.success) {
            val st = r.errors?.str("account_status")?.lowercase().orEmpty()
            return if (st in blockedStates) LoginOutcome.Blocked(r.message, st) else LoginOutcome.Fail(r.message)
        }
        val d = r.obj ?: return LoginOutcome.Fail(ErrorText.format(null, 500))
        if (d.flag("requireOtp")) {
            Session.email = d.str("email", email.trim())
            pendingPassword = password
            return LoginOutcome.NeedOtp
        }
        val token = d.str("token")
        if (token.isBlank()) return LoginOutcome.Fail(ErrorText.format(null, 500))
        Session.startSession(ctx, token, d.optJSONObject("user"), password)
        afterLogin(ctx)
        return LoginOutcome.Ok
    }

    /** OTP verify for registration (email_verification, no token), login (type login -> session) and reset (password_reset). */
    suspend fun verifyOtp(ctx: Context, email: String, otp: String, type: String): Pair<Boolean, String> {
        val r = AuthAPI.verifyOtp(email, otp, type)
        if (!r.success) return false to r.message
        val d = r.obj
        if (type == "login") {
            val token = d?.str("token").orEmpty()
            if (token.isBlank()) return false to ErrorText.format(null, 500)
            Session.startSession(ctx, token, d?.optJSONObject("user"), pendingPassword)
            pendingPassword = null
            d?.optJSONObject("user")?.let { applyPasscodeInfo(ctx, it) }
            afterLogin(ctx)
        } else if (type == "password_reset") {
            resetToken = d?.str("resetToken").orEmpty().ifBlank { d?.str("token").orEmpty() }
            resetOtp = otp
        }
        return true to r.message
    }

    var resetToken = ""
    var resetOtp = ""

    private suspend fun afterLogin(ctx: Context) {
        Sync.refresh(ctx)
    }

    /** Called with the PIN at the end of PIN creation: this is when the account is really created (register.php needs the PIN). */
    suspend fun register(ctx: Context, first: String, last: String, email: String, phone: String, password: String, pin: String, referral: String?): Pair<Boolean, String> {
        val r = AuthAPI.register(first.trim(), last.trim(), email.trim(), phone.trim(), password, pin, referral?.takeIf { it.isNotBlank() })
        if (!r.success) return false to r.message
        val token = r.obj?.str("token").orEmpty()
        if (token.isBlank()) return false to ErrorText.format(null, 500)
        Session.startSession(ctx, token, r.obj?.optJSONObject("user"), password)
        Session.setPayPinLocal(ctx, pin)
        Sync.refresh(ctx)
        return true to r.message
    }

    /** Mirrors the passcode sync in api.ts / App.tsx, minus storing the plain passcode (only the salted key is kept). */
    fun applyPasscodeInfo(ctx: Context, d: JSONObject) {
        val has = d.flag("has_passcode") || d.flag("passcode_set")
        if (has) {
            val key = d.str("passcode_local_key")
            if (key.length > 5) Session.passcodeHash = key
            else d.str("plain_passcode").ifBlank { d.str("passcode") }.takeIf { it.isNotBlank() }?.let { Session.passcodeHash = Session.localKey(it) }
            when (d.str("status")) { "active" -> Session.passcodeEnabled = true; "inactive" -> Session.passcodeEnabled = false }
            if (!d.has("status") && Session.passcodeHash != null && !Session.passcodeEnabled) Session.passcodeEnabled = true
        } else if (d.has("has_passcode") || d.has("passcode_set")) {
            Session.passcodeHash = null; Session.passcodeEnabled = false
        }
    }

    suspend fun setPasscode(ctx: Context, code: String): Pair<Boolean, String> {
        val r = UserAPI.setPasscode(code, Session.email, Session.accountId)
        if (!r.success) return false to r.message
        Session.setPasscodeLocal(ctx, code, r.obj?.str("passcode_local_key"))
        return true to r.message
    }

    /** verifyPasscodeUnified(): server first; the offline hash check is used only when the server is unreachable. */
    suspend fun verifyPasscode(ctx: Context, code: String): Pair<Boolean, String> {
        val r = UserAPI.verifyPasscode(code, Session.email, Session.accountId)
        if (r.success && r.obj?.flag("verified") == true) {
            Session.setPasscodeLocal(ctx, code, r.obj?.str("passcode_local_key"))
            return true to ""
        }
        if (!r.success && r.message == ErrorText.NO_NETWORK) {
            return if (Session.checkPasscode(code)) true to "" else false to "Incorrect passcode. Please check and try again."
        }
        return false to r.message.ifBlank { "Incorrect passcode. Please try again." }
    }

    suspend fun setPin(ctx: Context, pin: String): Pair<Boolean, String> {
        val r = UserAPI.setPin(pin)
        if (!r.success) return false to r.message
        Session.setPayPinLocal(ctx, pin)
        return true to r.message
    }

    suspend fun logout(ctx: Context) {
        AuthAPI.logout()
        Session.logout(ctx)
    }
}
