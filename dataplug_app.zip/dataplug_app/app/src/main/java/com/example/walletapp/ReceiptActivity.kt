package com.example.walletapp

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.os.Bundle
import android.widget.Toast
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.example.walletapp.ui.FrostedScreen
import com.example.walletapp.ui.AccentIcon
import com.example.walletapp.ui.Haptics
import com.example.walletapp.ui.Kind
import com.example.walletapp.ui.Seg
import com.example.walletapp.ui.TxLine
import com.example.walletapp.ui.elastic
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.walletapp.ui.AppColors
import com.example.walletapp.ui.AppToast
import com.example.walletapp.ui.AppFrame
import com.example.walletapp.ui.AppIcons
import com.example.walletapp.ui.FloatSurface
import com.example.walletapp.ui.ReceiptGenerator
import com.example.walletapp.ui.SvgIcon
import com.example.walletapp.ui.T
import com.example.walletapp.ui.TxIcon
import com.example.walletapp.ui.txLines
import com.example.walletapp.ui.Tx
import com.example.walletapp.ui.allTx
import com.example.walletapp.ui.pal
import com.example.walletapp.ui.pressable
import com.example.walletapp.ui.screenBackground
import com.example.walletapp.ui.u
import java.io.File
import java.io.FileOutputStream

/** Transaction details screen; the Share button generates and shares the receipt image. */
class ReceiptActivity : androidx.fragment.app.FragmentActivity() {
    // fade (and a small slide) when leaving, however the screen is closed
    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in_soft, R.anim.fade_out_soft)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(AColor.TRANSPARENT, AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(AColor.TRANSPARENT, AColor.TRANSPARENT)
        )
        val ref = intent.getStringExtra(EXTRA_REF)
        val tx = allTx.firstOrNull { it.reference == ref }
        if (tx == null) {
            finish()
            return
        }
        setContent { AppFrame { _, _ -> ReceiptScreen(tx, onBack = { finish() }) } }
    }

    companion object {
        const val EXTRA_REF = "tx_reference"
    }
}

@Composable
private fun ReceiptScreen(tx: Tx, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    val status = tx.status.uppercase()
    val statusColor = when (status) { "SUCCESSFUL" -> AppColors.Accent; "PENDING" -> Color(0xFFB7791F); else -> AppColors.ArrowUp }
    val statusLabel = when (status) { "SUCCESSFUL" -> "Successful"; "PENDING" -> "Pending"; else -> "Failed" }
    val scroll = rememberScrollState()

    FrostedScreen("Transaction details", onBack, scrollOffset = { scroll.value }, rubberBand = false) { top ->
        Column(Modifier.fillMaxSize().navigationBarsPadding()) {
          Box(Modifier.weight(1f).fillMaxWidth().elastic()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 21.u()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(top + 4.u()))
                // compact header: small icon, service name, amount, status
                TxIcon(tx, size = 44, corner = 14)
                Spacer(Modifier.height(10.u()))
                T(tx.title, 12.5f, FontWeight.Medium, p.textSecondary, maxLines = 1)
                Spacer(Modifier.height(4.u()))
                T("\u20A6" + tx.amount, 28f, FontWeight.Bold, maxLines = 1)
                Spacer(Modifier.height(10.u()))
                Box(
                    Modifier.background(statusColor.copy(alpha = 0.14f), RoundedCornerShape(50))
                        .padding(horizontal = 14.u(), vertical = 5.u())
                ) { T(statusLabel, 11.5f, FontWeight.SemiBold, statusColor) }
                Spacer(Modifier.height(20.u()))

                // every detail in its own card, like the profile screen
                val lines = remember(tx.reference) { txLines(tx) }
                var i = 0
                while (i < lines.size) {
                    val line = lines[i]
                    val next = lines.getOrNull(i + 1)
                    if (line.label == "Amount" && next != null && next.label == "Fee") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.u())) {
                            DetailCard(null, line, false, Modifier.weight(1f))
                            DetailCard(null, next, false, Modifier.weight(1f))
                        }
                        i += 2
                    } else {
                        DetailCard(
                            detailIcon(tx, line.label), line,
                            line.label == "Recipient" || line.label == "Token" || line.label == "Reference",
                            Modifier.fillMaxWidth()
                        )
                        i += 1
                    }
                    Spacer(Modifier.height(10.u()))
                }
                Spacer(Modifier.height(8.u()))
            }
          }

            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 21.u(), vertical = 14.u())
                    .height(54.u())
                    .pressable { shareReceipt(ctx, ReceiptGenerator.generate(ctx, tx), tx) }
                    .background(AppColors.Accent, RoundedCornerShape(18.u())),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SvgIcon(AppIcons.Share, 20.u(), Color.White, 2.2f)
                    Spacer(Modifier.width(10.u()))
                    T("Share receipt", 15f, FontWeight.Bold, Color.White)
                }
            }
        }
    }
}

private fun detailIcon(tx: Tx, label: String): List<Seg> = when (label) {
    "Service" -> AppIcons.Bills
    "Recipient" -> when (tx.kind) {
        Kind.Airtime, Kind.Data -> AppIcons.Phone
        Kind.Electricity -> AppIcons.Electricity
        Kind.Tv -> AppIcons.Tv
        Kind.Funding -> AppIcons.Bank
    }
    "Customer" -> AppIcons.Profile
    "Package Plan" -> AppIcons.Document
    "Token" -> AppIcons.Key
    "Units" -> AppIcons.Electricity
    "Reference" -> AppIcons.Document
    "Date & Time" -> AppIcons.History
    "Payment Method" -> AppIcons.WalletIn
    else -> AppIcons.Info
}

/** One transaction detail in its own card (same look as the profile info cards). [icon] = null gives the compact, icon-less version. */
@Composable
private fun DetailCard(icon: List<Seg>?, line: TxLine, copyable: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val p = pal()
    FloatSurface(modifier, RoundedCornerShape(20.u())) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.u(), vertical = if (icon == null) 12.u() else 11.u()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                AccentIcon(icon, 36, 18)
                Spacer(Modifier.width(12.u()))
            }
            Column(Modifier.weight(1f)) {
                T(line.label.uppercase(), 9f, FontWeight.SemiBold, p.textSecondary, spacing = 0.5f, maxLines = 1)
                Spacer(Modifier.height(3.u()))
                T(
                    line.value, 13.5f, if (line.bold || line.highlight) FontWeight.Bold else FontWeight.SemiBold,
                    if (line.highlight) AppColors.Accent else p.text,
                    maxLines = 2
                )
            }
            if (copyable) {
                Spacer(Modifier.width(8.u()))
                Box(
                    Modifier.size(34.u()).pressable {
                        clip.setText(AnnotatedString(line.value))
                        Haptics.tick(ctx)
                        AppToast.success("${line.label} copied")
                    }.background(AppColors.Accent.copy(alpha = 0.12f), RoundedCornerShape(11.u())),
                    contentAlignment = Alignment.Center
                ) { SvgIcon(AppIcons.Copy, 16.u(), AppColors.Accent, 2f) }
            }
        }
    }
}

private fun shareReceipt(ctx: Context, bmp: Bitmap, tx: Tx) {
    val dir = File(ctx.cacheDir, "receipts").apply { mkdirs() }
    val file = File(dir, "DataPlug_Receipt_${tx.reference}.png")
    FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_TEXT, "DataPlug Receipt - ${tx.reference}")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, "Share receipt").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
}
