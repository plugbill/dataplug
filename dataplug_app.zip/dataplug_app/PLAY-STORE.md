# Google Play readiness

## Fixed in this version
| Issue Play would raise | Fix |
|---|---|
| New apps/updates must target Android 16 (API 36) | targetSdk/compileSdk 36, AGP 8.9.2, Gradle 8.11.1 |
| Must upload an AAB | Workflow builds a signed AAB and an APK |
| Repeated versionCode rejected | versionCode comes from the GitHub run number |
| Back gesture on Android 16 | `enableOnBackInvokedCallback` enabled (screens already use Compose BackHandler) |
| Cleartext HTTP | `usesCleartextTraffic=false` + network security config (API is HTTPS) |
| Deprecated permission | `USE_FINGERPRINT` removed (`USE_BIOMETRIC` kept) |
| R8 obfuscation crashes / missing deobfuscation | keep rules added; mapping.txt is uploaded as an artifact and bundled in the AAB |
| Debug-key signing | release build refuses to build without the permanent key |
| Phones on Android 7/8 would crash | minSdk lowered 28 -> 24; java.time desugaring added; `getFont` -> `ResourcesCompat`; `VibrationEffect` guarded for API 26+; legacy launcher icon PNGs added for Android 7 |
| Exported boot receiver | `PlugBillBootReceiver` now `exported=false` (still receives system boot broadcasts) |
| Workflow only checked the signature | Workflow now also verifies package, minSdk 24, targetSdk 36+, not-debuggable, and runs bundletool validate on the AAB |
| Edge-to-edge | already enabled in MainActivity and ReceiptActivity |

## Things only you can do in Play Console
1. **Data safety form** and **Privacy policy URL**: use https://plugbill.linexware.net.ng/privacy-policy.html. State honestly: collects name, email, phone, financial/transaction info, device tokens (FCM).
2. **Account deletion**: the app has Delete account (Profile). Play also asks for a web page URL describing how to delete an account; add one on your site.
3. **Financial features declaration**: PlugBill is a bill payment / wallet app; answer that section accurately. No BVN is collected.
4. Content rating questionnaire, target audience (18+), app access instructions (give Play a demo login if reviewers must sign in).
5. First upload: opt in to Play App Signing. Create your store listing, icon 512x512 and screenshots.
6. If the old web-wrapper app with the same package name was already on Play with a higher versionCode, raise the `00` multiplier in build.yml.

## Known notes
- The screens lock to portrait. On Android 16 tablets/foldables that lock is ignored, which is only a quality warning.
- This build config could not be compiled where it was prepared; the first GitHub run is the real test.
